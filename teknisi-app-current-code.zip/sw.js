/* Service worker PWA — cache file lokal biar buka dari ikon HP terasa seperti aplikasi.
   Request ke Firebase / CDN tidak di-cache (tetap butuh internet). */
const CACHE = 'skaliska-shell-v68-safe-login';
const ASSETS = [
  './',
  './index.html',
  './styles.css',
  './final-ui.css',
  './app.js',
  './manifest.json',
  './logo-skaliska.jpg',
  './logo-mark.jpg',
  './logo-skaliska-mark.svg',
  './logo-skaliska-real.png',
  './logo-mark-shield.png',
  './logo-skaliska-clean.svg',
  './logo-mark-transparent.png',
  './logo-original-for-edit.jpg',
  './firebase-app-compat.js',
  './firebase-firestore-compat.js',
  './firebase-storage-compat.js',
  './fonts/PlusJakartaSans-SemiBold.woff2',
  './fonts/PlusJakartaSans-Bold.woff2',
  './fonts/PlusJakartaSans-ExtraBold.woff2',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png',
  './icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  const isPage = event.request.mode === 'navigate' || url.pathname.endsWith('.html') || url.pathname === '/' || url.pathname.endsWith('/');

  if (isPage) {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, copy));
          return res;
        })
        .catch(() => caches.match(event.request).then((hit) => hit || caches.match('./index.html')))
    );
    return;
  }

  const isCode = /\.(js|css)$/.test(url.pathname);
  if (isCode) {
    event.respondWith(fetch(event.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((cache) => cache.put(event.request, copy));
      return res;
    }).catch(() => caches.match(event.request)));
    return;
  }

  event.respondWith(
    caches.match(event.request).then((hit) => {
      if (hit) return hit;
      return fetch(event.request).then((res) => {
        if (!res || res.status !== 200) return res;
        const copy = res.clone();
        caches.open(CACHE).then((cache) => cache.put(event.request, copy));
        return res;
      });
    })
  );
});
