const firebaseConfig = {
  apiKey: 'AIzaSyDw8AhXns--g4t_vKwI4QAHzw-pvu3OZjY',
  authDomain: 'teknisi-skaliska.firebaseapp.com',
  projectId: 'teknisi-skaliska',
  storageBucket: 'teknisi-skaliska.firebasestorage.app',
  messagingSenderId: '736577586416',
  appId: '1:736577586416:web:cb8017132e829d92226e35'
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const storage = firebase.storage();
const SKALISKA_DB_RECONNECT_V60 = true;
try { db.enableNetwork && db.enableNetwork().catch(function(e){ console.warn('Firestore enableNetwork:', e && e.message ? e.message : e); }); } catch (e) {}
try { db.settings({ cacheSizeBytes: 10485760, ignoreUndefinedProperties: true }); } catch (e) {}
try { if (!window.SKALISKA_LITE) db.enablePersistence({ synchronizeTabs: false }).catch(function () {}); } catch (e) {}

const MAX_ITEM_IMAGE_CHARS = 700000;
const MAX_BUKTI_CHARS = 180000;
const RIWAYAT_LIMIT = 60;
const LOGIN_BTN = '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path></svg><span>Masuk Sistem</span>';
const SPIN = '<svg class="animate-spin h-5 w-5 inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg><span class="ml-2 font-bold">Proses...</span>';
const BOX_PATH = 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4';

let currentUser = { name: '', role: '' };
let gudangData = [];
let riwayatData = [];
let usersData = [];
let pendingRequests = [];
let pinjamanData = [];
let userPinjamanMap = {};
let userPendingReturnMap = {};
let announceData = [];
let unsub = { pinjam: null, users: null, req: null, myReq: null, gudang: null, riwayat: null, reqNotify: null, annNotify: null, absen: null, announce: null };
let buktiBusy = false;
let buktiToken = 0;
const BLN = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
let absenMonth = new Date().getMonth() + 1;
let absenYear = new Date().getFullYear();
let absenData = [];
let absenFocus = '';
let absenTypeResolve = null;
let editUserId = '';
let itemSheetId = '';
let confirmResolve = null;
let currentFilter = 'semua';
let logFilter = 'semua';
let logQuery = '';
let pendingLogoFile = null;
let currentLogoUrl = '';
let processingIds = new Set();
let lastGudangSig = '';
const blobCache = new Map();
const QKEY = 'sk_q';
function readQ() { try { return JSON.parse(localStorage.getItem(QKEY) || '[]'); } catch (e) { return []; } }
function writeQ(a) { try { localStorage.setItem(QKEY, JSON.stringify(a.slice(-30))); } catch (e) {} }
function enqueue(t, payload) {
  const q = readQ();
  q.push({ t, p: payload, at: Date.now(), n: 0 });
  writeQ(q);
  toast('Tersimpan offline. Kirim otomatis saat online.', 'warning');
}
let qBusy = false;
function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, rej) => setTimeout(() => rej(new Error(label || 'Koneksi timeout. Coba lagi.')), ms))
  ]);
}
function isPermErr(e) {
  const m = String((e && e.message) || e || '');
  return /permission|PERMISSION_DENIED|INVALID_ARGUMENT|exceeds|too large|resource-exhausted|unauthenticated/i.test(m);
}
async function queueFlush() {
  if (qBusy || !navigator.onLine) return;
  qBusy = true;
  try {
    const q = readQ();
    if (!q.length) return;
    const rest = [];
    let ok = 0;
    for (let i = 0; i < q.length; i++) {
      const item = q[i];
      const tries = (item.n || 0) + 1;
      try {
        if (item.t === 'return') await withTimeout(db.collection('return_requests').add(item.p), 15000, 'Timeout kirim pengembalian.');
        else if (item.t === 'absen') await withTimeout(db.collection('absen').add(item.p), 15000, 'Timeout kirim absen.');
        else if (item.t === 'announce') await withTimeout(db.collection('pengumuman').add(item.p), 15000, 'Timeout kirim pengumuman.');
        else continue;
        ok++;
      } catch (e) {
        if (!isPermErr(e) && tries < 3) rest.push({ t: item.t, p: item.p, at: item.at, n: tries });
      }
    }
    writeQ(rest);
    if (ok) toast(ok + ' data offline terkirim.', 'success');
  } finally { qBusy = false; }
}
function isNetErr(e) {
  const m = String((e && e.message) || e || '');
  return !navigator.onLine || /unavailable|offline|network|Failed to get document|UNAVAILABLE/i.test(m);
}
function nativePdf(name, text) {
  try {
    if (window.SkaliskaNotify && window.SkaliskaNotify.savePdf) {
      window.SkaliskaNotify.savePdf(String(name || 'laporan.pdf'), String(text || ''));
      return true;
    }
  } catch (e) {}
  return false;
}
function syncAlarms() {
  try {
    if (!window.SkaliskaNotify || typeof window.SkaliskaNotify.cancelAll !== 'function') return;
    window.SkaliskaNotify.cancelAll();
    if (!currentUser.name) return;
    const mine = pinjamanData.filter((p) => p.user === currentUser.name);
    mine.forEach((p) => {
      if (!p.jatuhTempo) return;
      const day = new Date(String(p.jatuhTempo) + 'T07:00:00');
      const before = new Date(day.getTime() - 86400000);
      const now = Date.now();
      const nama = p.barangNama || 'Barang';
      if (before.getTime() > now) window.SkaliskaNotify.schedule('t-' + p.id, before.getTime(), 'Besok jatuh tempo', nama + ' harus kembali besok');
      if (day.getTime() > now) window.SkaliskaNotify.schedule('d-' + p.id, day.getTime(), 'Jatuh tempo hari ini', nama + ' harus dikembalikan hari ini');
    });
    const rec = absenOf(currentUser.name).find((a) => a.tgl === todayKey());
    if (!rec) {
      const d = new Date();
      d.setHours(7, 0, 0, 0);
      if (d.getTime() > Date.now()) window.SkaliskaNotify.schedule('absen', d.getTime(), 'Belum absen', 'Isi absen hari ini.');
    }
  } catch (e) {}
}
const syncAlarmsSoon = debounce(syncAlarms, 900);

const $ = (id) => document.getElementById(id);
const lite = () => !!window.SKALISKA_LITE;
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const haptic = (p) => { if (!lite() && navigator.vibrate) navigator.vibrate(p); };
const esc = (s) => typeof s === 'string' ? s.replace(/[&<>'"]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[m])) : s;
const svg = (d, cls = 'w-4 h-4') => `<svg class="${cls}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="${d}"></path></svg>`;
function debounce(fn, ms) {
  let t;
  return function () { clearTimeout(t); t = setTimeout(() => fn.apply(this, arguments), ms); };
}
function stop(key) { if (unsub[key]) { unsub[key](); unsub[key] = null; } }
function setBusy(id, on, html) {
  const btn = $(id);
  if (!btn) return;
  btn.disabled = on;
  btn.innerHTML = on ? SPIN : html;
}
function todayKey() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function ymFromTgl(tgl) { return String(tgl || '').slice(0, 7); }
function kondisiOf(it) { return (it && it.kondisi) || 'baik'; }
function canBorrow(it) { return !!it && num(it.stok) > 0 && kondisiOf(it) === 'baik'; }
function isAdmin() { return currentUser.role === 'admin'; }
function isKetua() { return currentUser.role === 'ketua'; }
function isStaff() { return isAdmin() || isKetua(); }
function canPinjam() { return currentUser.role === 'user' || currentUser.role === 'ketua'; }
function canEditStock() { return isAdmin(); }
function canManageUsers() { return isAdmin(); }
function roleLabel(r) {
  if (r === 'admin') return 'Admin';
  if (r === 'ketua') return 'Ketua';
  return 'Teknisi';
}
function memberRole(u) {
  if (u && u.role === 'admin') return 'admin';
  if (u && u.role === 'ketua') return 'ketua';
  return 'teknisi';
}
function roleFromDoc(d) {
  if (!d) return 'user';
  if (d.role === 'admin') return 'admin';
  if (d.role === 'ketua') return 'ketua';
  return 'user';
}
function hideBoot() { $('boot-splash')?.classList.add('gone'); }
function isOverdue(p) { return !!(p && p.jatuhTempo && String(p.jatuhTempo) < todayKey()); }
function fmtTgl(s) {
  if (!s) return 'Tanpa tempo';
  const p = String(s).split('-');
  if (p.length < 3) return String(s);
  const m = num(p[1]);
  return num(p[2]) + ' ' + (BLN[m - 1] || p[1]).slice(0, 3) + ' ' + p[0];
}
function toast(msg, type = 'info') {
  const box = $('toast-container');
  if (!box) return;
  const el = document.createElement('div');
  const c = { info: '#60A5FA', success: '#34D399', error: '#F87171', warning: '#FBBF24' }[type] || '#60A5FA';
  el.className = 'toast-wrap toast-in pointer-events-auto';
  el.innerHTML = `<div class="toast-dot" style="background:${c}"></div><span>${esc(msg)}</span>`;
  box.appendChild(el);
  haptic(40);
  setTimeout(() => { el.classList.add('toast-out'); setTimeout(() => el.remove(), 280); }, 2800);
}
function ask(msg, detail = 'Tindakan ini permanen dan tak bisa dibatalkan.', yesLabel = 'Hapus') {
  return new Promise((resolve) => {
    $('confirm-message').textContent = msg;
    $('confirm-detail').textContent = detail;
    if ($('confirm-yes')) $('confirm-yes').textContent = yesLabel || 'Hapus';
    $('confirm-dialog').classList.remove('hidden');
    confirmResolve = resolve;
    haptic([40, 40, 40]);
  });
}
function closeAsk(ok) {
  $('confirm-dialog').classList.add('hidden');
  if (confirmResolve) { confirmResolve(ok); confirmResolve = null; }
}

function itemImage(id, src) {
  if (!src) return '';
  if (src.length < 12) return '';
  if (!src.startsWith('data:')) return src;
  const prev = blobCache.get(id);
  if (prev && prev.len === src.length) return prev.url;
  if (prev) URL.revokeObjectURL(prev.url);
  try {
    const i = src.indexOf(',');
    const mime = (src.slice(5, i).split(';')[0]) || 'image/jpeg';
    const bin = atob(src.slice(i + 1));
    const bytes = new Uint8Array(bin.length);
    for (let n = 0; n < bin.length; n++) bytes[n] = bin.charCodeAt(n);
    const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
    blobCache.set(id, { url, len: src.length });
    return url;
  } catch (e) { return src; }
}
function clearBlobs() {
  blobCache.forEach((v) => URL.revokeObjectURL(v.url));
  blobCache.clear();
}

const DEFAULT_LOGO = 'logo-mark-shield.png';
function applyLogo(url) {
  currentLogoUrl = url || '';
  // Firebase/settings tetap dipakai untuk custom logo. Default bawaan diarahkan ke shield PNG transparan.
  const raw = String(url || '');
  const isOldDefault = !raw || raw.includes('logo-mark.jpg') || raw.includes('logo-mark-transparent') || raw.includes('logo-skaliska-mark') || raw.includes('logo-skaliska-clean') || raw.includes('logo-skaliska-real') || raw.includes('logo-skaliska.jpg');
  const src = isOldDefault ? DEFAULT_LOGO : raw;
  ['login', 'header', 'settings'].forEach((p) => {
    const ico = $(`${p}-logo-svg`);
    const img = $(`${p}-logo-img`);
    if (!ico || !img) return;
    ico.classList.add('hidden');
    img.src = src;
    img.classList.remove('hidden');
  });
}


function previewLogoUpload(input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  if (!file.type.startsWith('image/')) { toast('File logo harus berupa gambar!', 'error'); input.value = ''; return; }
  if (file.size > 2 * 1024 * 1024) { toast('Logo maks 2MB!', 'error'); input.value = ''; return; }
  pendingLogoFile = file;
  const r = new FileReader();
  r.onload = (e) => { const img = $('settings-logo-img'); img.src = e.target.result; img.classList.remove('hidden'); $('settings-logo-svg').classList.add('hidden'); };
  r.onerror = () => toast('Gagal membaca file logo.', 'error');
  r.readAsDataURL(file);
}
function openSettingsModal() {
  if (!isAdmin()) return;
  pendingLogoFile = null;
  $('logo-file-input').value = '';
  $('logo-upload-progress-wrap').classList.add('hidden');
  applyLogo(currentLogoUrl);
  $('settings-modal').classList.remove('hidden');
}
function closeSettingsModal() { $('settings-modal').classList.add('hidden'); pendingLogoFile = null; }
async function saveLogo() {
  if (!pendingLogoFile) { toast('Pilih file logo dulu!', 'warning'); return; }
  const wrap = $('logo-upload-progress-wrap');
  const bar = $('logo-upload-bar');
  wrap.classList.remove('hidden');
  setBusy('btn-save-logo', true, svg('M5 13l4 4L19 7') + 'Simpan Logo');
  try {
    const name = `logo_${Date.now()}_${pendingLogoFile.name.replace(/[^a-zA-Z0-9.\\-]/g, '_')}`;
    const task = storage.ref(`settings/${name}`).put(pendingLogoFile);
    await new Promise((res, rej) => task.on('state_changed', (s) => {
      const pct = Math.round((s.bytesTransferred / s.totalBytes) * 100);
      bar.style.width = pct + '%';
      $('logo-upload-pct').textContent = pct + '%';
    }, rej, res));
    const url = await task.snapshot.ref.getDownloadURL();
    await db.collection('settings').doc('appConfig').set({ logoUrl: url }, { merge: true });
    toast('Logo diperbarui!', 'success');
    pendingLogoFile = null;
    closeSettingsModal();
  } catch (e) { toast('Upload gagal: ' + e.message, 'error'); }
  finally {
    wrap.classList.add('hidden');
    bar.style.width = '0%';
    setBusy('btn-save-logo', false, svg('M5 13l4 4L19 7') + 'Simpan Logo');
  }
}
async function resetLogo() {
  if (!(await ask('Reset logo ke default?', 'Logo custom akan dihapus.', 'Reset'))) return;
  try {
    await db.collection('settings').doc('appConfig').set({ logoUrl: '' }, { merge: true });
    toast('Logo direset.', 'success');
    closeSettingsModal();
  } catch (e) { toast('Gagal reset: ' + e.message, 'error'); }
}

async function deleteDocs(col, ids) {
  const CHUNK = 400;
  for (let i = 0; i < ids.length; i += CHUNK) {
    const batch = db.batch();
    ids.slice(i, i + CHUNK).forEach((id) => batch.delete(db.collection(col).doc(id)));
    await batch.commit();
  }
}
async function clearAllLog() {
  if (!isAdmin()) return;
  if (!(await ask('Hapus semua log?', 'Semua entri riwayat akan dihapus permanen.', 'Hapus'))) return;
  const btn = $('btn-clear-log');
  if (btn) btn.disabled = true;
  try {
    const snap = await db.collection('riwayat').get();
    await deleteDocs('riwayat', snap.docs.map((d) => d.id));
    toast(snap.size + ' log dihapus!', 'success');
  } catch (e) { toast('Gagal hapus: ' + e.message, 'error'); }
  finally { if (btn) btn.disabled = false; }
}

function updateKpis() {
  const sku = gudangData.length;
  const stok = gudangData.reduce((a, i) => a + num(i.stok), 0);
  const low = gudangData.filter((i) => { const s = num(i.stok); return s > 0 && s <= 3 && kondisiOf(i) === 'baik'; }).length;
  const pinjamN = pinjamanData.reduce((a, p) => a + num(p.jumlah || 1), 0);
  const overdue = pinjamanData.some(isOverdue);
  if ($('kpi-sku')) $('kpi-sku').textContent = String(sku);
  if ($('stat-total-items')) $('stat-total-items').textContent = String(stok);
  if ($('kpi-low')) $('kpi-low').textContent = String(low);
  if ($('kpi-pinjam')) $('kpi-pinjam').textContent = String(pinjamN);
  $('kpi-low-btn')?.classList.toggle('kpi-warn', low > 0);
  $('kpi-pinjam-btn')?.classList.toggle('kpi-hot', overdue);
  updatePinjamanDisplay();
  renderHub();
}

function updatePinjamanDisplay() {
  const el = $('user-pinjaman-info');
  if (!el) return;
  if (!canPinjam()) { el.classList.add('hidden'); return; }
  const total = Object.values(userPinjamanMap).reduce((a, b) => a + b, 0);
  if (total > 0) {
    el.innerHTML = `<span class="pinjaman-tap" onclick="openPinjamBoard()">${svg('M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4','w-3.5 h-3.5')}<span>${total} item sedang dipinjam</span></span>`;
    el.classList.remove('hidden');
  } else el.classList.add('hidden');
}

function setFilter(filter) {
  currentFilter = filter;
  document.querySelectorAll('#gudang-view .filter-pill').forEach((b) => b.classList.toggle('active', b.dataset.filter === filter));
  haptic(15);
  lastGudangSig = '';
  renderGudangList();
}
function focusLowStock() {
  switchTab('gudang');
  setFilter('rendah');
}
let lastCatSig = '';
function renderCatPills() {
  const host = $('cat-pills');
  if (!host) return;
  const cats = [...new Set(gudangData.map((i) => i.kategori || 'Lainnya'))].sort((a, b) => a.localeCompare(b, 'id'));
  const sig = cats.join('|') + currentFilter;
  if (sig === lastCatSig) return;
  lastCatSig = sig;
  host.innerHTML = cats.map((c) => `<button onclick="setFilter('kat:${esc(c)}')" data-filter="kat:${esc(c)}" class="filter-pill${currentFilter === 'kat:' + c ? ' active' : ''}">${esc(c)}</button>`).join('');
}
function setLogFilter(f) {
  logFilter = f;
  document.querySelectorAll('[data-log]').forEach((b) => b.classList.toggle('active', b.dataset.log === f));
  renderRiwayatList();
}
function setLogQuery(q) {
  logQuery = String(q || '').toLowerCase().trim();
  renderRiwayatList();
}
function stepStok(n) {
  const el = $('edit-stok');
  el.value = String(Math.max(0, num(el.value) + n));
}
function showPreview(src, name, extra) {
  if (!src) return;
  $('preview-img').src = src;
  $('preview-name').textContent = name || '';
  const ps = $('preview-seri');
  if (ps) {
    if (extra) { ps.textContent = extra; ps.classList.remove('hidden'); }
    else { ps.textContent = ''; ps.classList.add('hidden'); }
  }
  $('preview-layer').classList.remove('hidden');
}
function openPreview(id) {
  const it = gudangData.find((b) => b.id === id);
  if (!it || !it.img) return;
  showPreview(it.img, it.nama || '', it.seri || '');
}
function openBukti(id) {
  const r = pendingRequests.find((x) => x.id === id) || {};
  const src = itemImage('bukti-' + (r.id || id), r.buktiUrl || '');
  if (!src) { toast('Tidak ada foto bukti.', 'warning'); return; }
  showPreview(src, r.barangNama || 'Bukti', (r.user || '') + (r.catatan ? ' · ' + r.catatan : ''));
}
function closePreview() { $('preview-layer').classList.add('hidden'); }
async function exportLog() {
  if (!isStaff()) return;
  const rows = ['waktu,user,aksi,barang'];
  riwayatData.slice().sort((a, b) => (b.waktu || 0) - (a.waktu || 0)).forEach((d) => {
    rows.push([new Date(d.waktu || 0).toISOString(), d.user || '', d.aksi || '', d.barang || ''].map((x) => `"${String(x).replace(/"/g, '""')}"`).join(','));
  });
  const text = rows.join('\n');
  if (nativePdf('riwayat-skaliska.pdf', text)) { toast('PDF riwayat siap dibagikan.', 'success'); return; }
  const blob = new Blob([text], { type: 'text/csv' });
  const file = new File([blob], 'riwayat-skaliska.csv', { type: 'text/csv' });
  if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ title: 'Riwayat Skaliska', files: [file] }); return; } catch (e) {}
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'riwayat-skaliska.csv';
  a.click();
  toast('File CSV disimpan.', 'success');
}

function stockBadge(it) {
  const stok = num(it.stok);
  const k = kondisiOf(it);
  if (k === 'rusak') return { badge: 'badge-zero', label: 'Rusak', health: 'health-bad', alert: false };
  if (k === 'servis') return { badge: 'badge-low', label: 'Servis', health: 'health-srv', alert: false };
  if (stok === 0) return { badge: 'badge-zero', label: 'Habis', health: 'health-zero', alert: false };
  if (stok <= 3) return { badge: 'badge-low', label: 'Sisa ' + stok, health: 'health-low', alert: true };
  return { badge: 'badge-ok', label: String(stok), health: 'health-ok', alert: false };
}

function renderGudangList() {
  const list = $('gudang-list');
  const empty = $('gudang-empty');
  if (!list) return;
  const q = ($('search-input')?.value || '').toLowerCase().trim();
  const filtered = gudangData.filter((it) => {
    const nama = (it.nama || '').toLowerCase();
    const kat = (it.kategori || '').toLowerCase();
    const lok = (it.lokasi || '').toLowerCase();
    const seri = (it.seri || '').toLowerCase();
    const k = kondisiOf(it);
    const stok = num(it.stok);
    if (q && !nama.includes(q) && !kat.includes(q) && !lok.includes(q) && !seri.includes(q)) return false;
    if (currentFilter === 'tersedia' && !canBorrow(it)) return false;
    if (currentFilter === 'habis' && stok > 0) return false;
    if (currentFilter === 'rendah' && !(stok > 0 && stok <= 3 && k === 'baik')) return false;
    if (currentFilter === 'cek' && k === 'baik') return false;
    if (currentFilter.startsWith('kat:') && (it.kategori || 'Lainnya') !== currentFilter.slice(4)) return false;
    return true;
  }).sort((a, b) => (a.nama || '').localeCompare(b.nama || '', 'id'));
  const sig = [currentUser.role, currentFilter, q, filtered.map((i) => [i.id, i.stok || 0, i.nama || '', i.seri || '', i.img || '', i.kondisi || '', userPinjamanMap[i.id] || 0, userPendingReturnMap[i.id] ? 1 : 0].join(':')).join(',')].join('|');
  updateKpis();
  if (sig === lastGudangSig) return;
  lastGudangSig = sig;

  syncDashDot();
  renderCatPills();

  if (!filtered.length) { list.innerHTML = ''; empty?.classList.remove('hidden'); return; }
  empty?.classList.add('hidden');
  list.innerHTML = filtered.map((it) => {
    const id = it.id;
    const sb = stockBadge(it);
    const alertIco = sb.alert ? `<span class="stock-alert">${svg('M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z','w-3.5 h-3.5')}</span>` : '';
    const img = it.img
      ? `<img src="${it.img}" class="w-full h-full object-cover" loading="lazy" alt="">`
      : svg(BOX_PATH, 'w-6 h-6 c-blue');
    const bits = [it.seri || '', it.kategori || 'Lainnya', it.lokasi || '-'].filter(Boolean);
    return `<button type="button" class="inv-row" onclick="openItemSheet('${id}')">
      <span class="health ${sb.health}"></span>
      <div class="item-img-wrap sm">${img}</div>
      <div class="inv-row-body">
        <h4>${esc(it.nama)}</h4>
        <p class="inv-row-meta">${esc(bits.join(' · '))}</p>
      </div>
      <div class="stock-side">${alertIco}<span class="text-xs font-black px-2.5 py-1 rounded-xl border shrink-0 ${sb.badge}">${esc(sb.label)}</span></div>
    </button>`;
  }).join('');
}

function openItemSheet(id) {
  const it = gudangData.find((b) => b.id === id);
  if (!it) return;
  itemSheetId = id;
  const wrap = $('item-sheet-img-wrap');
  if (wrap) {
    wrap.innerHTML = it.img
      ? `<img src="${it.img}" class="w-full h-full object-cover" alt="" onclick="openPreview('${id}')">`
      : svg(BOX_PATH, 'w-7 h-7 c-blue');
  }
  if ($('item-sheet-nama')) $('item-sheet-nama').textContent = it.nama || '';
  const seri = $('item-sheet-seri');
  if (seri) {
    if (it.seri) { seri.textContent = it.seri; seri.classList.remove('hidden'); }
    else { seri.textContent = ''; seri.classList.add('hidden'); }
  }
  if ($('item-sheet-meta')) $('item-sheet-meta').textContent = (it.kategori || 'Lainnya') + ' · ' + (it.lokasi || '-');
  const sb = stockBadge(it);
  const flags = $('item-sheet-flags');
  if (flags) {
    flags.innerHTML = `<span class="text-xs font-black px-2.5 py-1 rounded-xl border ${sb.badge}">${esc(sb.label)}</span>
      <span class="flag-chip">${esc(kondisiOf(it) === 'baik' ? 'Baik' : kondisiOf(it) === 'rusak' ? 'Rusak' : 'Servis')}</span>`;
  }
  const holders = pinjamanData.filter((p) => p.barangId === id);
  if (flags && holders.length) {
    const who = holders.map((p) => (p.user || '-') + (isOverdue(p) ? ' · telat' : '')).join(', ');
    flags.innerHTML += `<span class="flag-chip hold">${esc(who)}</span>`;
  }
  const tempoBox = $('item-sheet-tempo');
  const pinjam = canPinjam() ? (userPinjamanMap[id] || 0) : 0;
  const pending = !!userPendingReturnMap[id];
  if (tempoBox) {
    if (canPinjam() && canBorrow(it)) {
      tempoBox.classList.remove('hidden');
      const inp = $('pinjam-tempo');
      if (inp) { inp.min = todayKey(); if (!inp.value) inp.value = ''; }
    } else tempoBox.classList.add('hidden');
  }
  const actions = $('item-sheet-actions');
  if (actions) {
    const bits = [];
    if (canEditStock()) bits.push(`<button onclick="closeItemSheet();openBarangModal('${id}')" class="w-full py-3 text-sm font-bold rounded-2xl btn-edit">Edit Barang</button>`);
    if (canPinjam()) {
      const retOff = pinjam === 0 || pending;
      const pinOff = !canBorrow(it);
      bits.push(`<button onclick="startKembali('${id}')" class="flex-1 py-3 text-sm font-bold rounded-2xl btn-return" ${retOff ? 'disabled' : ''}>${pending ? 'Menunggu' : (pinjam > 0 ? 'Kembali (' + pinjam + ')' : 'Kembali')}</button><button onclick="pinjamBarang('${id}', this)" class="flex-1 py-3 text-sm font-bold rounded-2xl btn-borrow" ${pinOff ? 'disabled' : ''}>Pinjam</button>`);
    }
    actions.innerHTML = bits.join('') || '<p class="text-xs font-bold c-text-3">Hanya lihat.</p>';
  }
  frontOverlay($('item-modal'));
}
function closeItemSheet() {
  const el = $('item-modal');
  if (el) { el.classList.add('hidden'); el.classList.remove('is-on'); el.style.display = 'none'; }
  itemSheetId = '';
}

function openPinjamBoard() {
  renderPinjamBoard();
  frontOverlay($('pinjam-board'));
}
function closePinjamBoard() {
  const el = $('pinjam-board');
  if (el) { el.classList.add('hidden'); el.classList.remove('is-on'); el.style.display = 'none'; }
}
function renderPinjamBoard() {
  const list = $('pinjam-board-list');
  const sub = $('pinjam-board-sub');
  const cnt = $('pinjam-board-count');
  if (!list) return;
  const rows = pinjamanData.slice().sort((a, b) => {
    const ou = Number(isOverdue(b)) - Number(isOverdue(a));
    if (ou) return ou;
    const u = (a.user || '').localeCompare(b.user || '', 'id');
    return u || (a.waktu || 0) - (b.waktu || 0);
  });
  const n = rows.reduce((a, p) => a + num(p.jumlah || 1), 0);
  if (cnt) cnt.innerHTML = 'Aktif<small>' + n + '</small>';
  if (sub) sub.textContent = isStaff() ? 'Semua teknisi · tap Kembali untuk tarik stok' : 'Barang yang sedang kamu pegang';
  if (!rows.length) {
    list.innerHTML = '<p class="pinjam-empty">Tidak ada barang yang sedang dipinjam.</p>';
    return;
  }
  const staff = isStaff();
  let lastUser = '';
  list.innerHTML = rows.map((p) => {
    const late = isOverdue(p);
    const head = staff && p.user !== lastUser ? `<p class="pinjam-group">${esc(p.user || '-')}</p>` : '';
    lastUser = p.user;
    const tempo = p.jatuhTempo
      ? (late ? 'Telat · ' + fmtTgl(p.jatuhTempo) : 'Tempo ' + fmtTgl(p.jatuhTempo))
      : 'Tanpa tempo';
    const when = p.waktu ? new Date(p.waktu).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) : '';
    const act = staff
      ? `<button type="button" class="btn-return px-3 py-2 rounded-xl text-xs font-bold" onclick="tarikPinjaman('${p.id}')">Kembali</button>`
      : (userPendingReturnMap[p.barangId]
        ? `<span class="text-[11px] font-bold c-text-3">Menunggu</span>`
        : `<button type="button" class="btn-return px-3 py-2 rounded-xl text-xs font-bold" onclick="startKembali('${p.barangId}')">Kembali</button>`);
    return `${head}<div class="pinjam-row${late ? ' late' : ''}">
      <div class="flex-1 min-w-0">
        <p class="font-black text-sm truncate">${esc(p.barangNama || 'Barang')}</p>
        <p class="text-[11px] font-bold mt-0.5 ${late ? 'late-txt' : 'c-text-3'}">${esc(tempo)}${when ? ' · dari ' + when : ''}${num(p.jumlah) > 1 ? ' · x' + num(p.jumlah) : ''}</p>
      </div>
      ${act}
    </div>`;
  }).join('');
}


function riwayatSummaryHtml(rows) {
  const pinjam = rows.filter((d) => d.aksi === 'pinjam').length;
  const kembali = rows.filter((d) => d.aksi === 'kembali').length;
  const gagal = rows.filter((d) => d.aksi === 'tolak_kembali').length;
  const today = todayKey();
  const todayCount = rows.filter((d) => d.waktu && new Date(d.waktu).toISOString().slice(0,10) === today).length;
  return `<div class="log-summary">
    <div><b>${todayCount}</b><span>Hari ini</span></div>
    <div><b>${pinjam}</b><span>Pinjam</span></div>
    <div><b>${kembali}</b><span>Kembali</span></div>
    <div><b>${gagal}</b><span>Ditolak</span></div>
  </div>`;
}

function renderRiwayatList() {
  const list = $('riwayat-list');
  const empty = $('riwayat-empty');
  const sec = $('pending-requests-section');
  const badge = $('pending-requests-badge');
  if (isStaff()) {
    sec.classList.remove('hidden');
    if (pendingRequests.length) {
      badge.classList.remove('hidden');
      $('pending-requests-count').textContent = pendingRequests.length;
      sec.innerHTML = `<h4 class="text-xs font-black uppercase tracking-widest mb-3 flex items-center gap-2 text-amber-600">${svg('M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9')} Menunggu Persetujuan (${pendingRequests.length})</h4><div class="space-y-3">${pendingRequests.map((r) => {
        const thumbSrc = itemImage('bukti-' + r.id, r.buktiUrl || '');
        const thumb = thumbSrc ? `<img src="${thumbSrc}" class="bukti-thumb" alt="" onclick="openBukti('${r.id}')">` : `<div class="bukti-thumb" style="display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:#92400E">No foto</div>`;
        const note = r.catatan ? `<p class="text-[11px] font-semibold mt-1 c-text-2">${esc(r.catatan)}</p>` : '';
        return `<div class="req-card"><div class="flex items-center gap-3">${thumb}<div class="flex-1 min-w-0"><p class="text-sm font-semibold c-text"><span class="font-black text-amber-700">${esc(r.user)}</span> ingin mengembalikan <span class="font-black">${esc(r.barangNama)}</span></p>${note}<p class="text-[10px] font-bold mt-0.5 c-text-3">${new Date(r.waktu).toLocaleString('id-ID')}</p></div><div class="flex gap-2 shrink-0"><button onclick="approveReturn('${r.id}', this)" class="w-9 h-9 bg-green-500 text-white rounded-xl flex items-center justify-center">${svg('M5 13l4 4L19 7')}</button><button onclick="rejectReturn('${r.id}', this)" class="w-9 h-9 bg-red-500 text-white rounded-xl flex items-center justify-center">${svg('M6 18L18 6M6 6l12 12')}</button></div></div></div>`;
      }).join('')}</div>`;
    } else { badge.classList.add('hidden'); sec.innerHTML = ''; }
  } else { sec.classList.add('hidden'); badge.classList.add('hidden'); }
  syncDashDot();

  const sorted = riwayatData.filter((d) => {
    if (logFilter === 'pinjam') return d.aksi === 'pinjam';
    if (logFilter === 'kembali') return d.aksi === 'kembali' || d.aksi === 'tolak_kembali';
    return true;
  }).filter((d) => {
    if (!logQuery) return true;
    return String(d.user || '').toLowerCase().includes(logQuery) || String(d.barang || '').toLowerCase().includes(logQuery);
  }).sort((a, b) => (b.waktu || 0) - (a.waktu || 0));
  if (!sorted.length) { list.innerHTML = ''; empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  const today = new Date().toLocaleDateString('id-ID');
  const y = new Date(); y.setDate(y.getDate() - 1);
  const yest = y.toLocaleDateString('id-ID');
  const grouped = {};
  sorted.forEach((d) => {
    const ds = new Date(d.waktu).toLocaleDateString('id-ID');
    let g = new Date(d.waktu).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
    if (ds === today) g = 'Hari Ini';
    else if (ds === yest) g = 'Kemarin';
    (grouped[g] || (grouped[g] = [])).push(d);
  });
  list.innerHTML = riwayatSummaryHtml(sorted) + Object.keys(grouped).map((g) => `<div class="log-group fade-up"><p class="log-date">${g}</p><div class="log-stack">${grouped[g].map((d) => {
    const pinjam = d.aksi === 'pinjam';
    const reject = d.aksi === 'tolak_kembali';
    const cls = pinjam ? 'log-icon-pinjam' : reject ? 'log-icon-reject' : 'log-icon-return';
    const path = pinjam ? 'M7 11l5-5m0 0l5 5m-5-5v12' : reject ? 'M6 18L18 6M6 6l12 12' : 'M17 13l-5 5m0 0l-5-5m5 5V6';
    const word = pinjam ? 'Meminjam' : d.aksi === 'kembali' ? 'Mengembalikan' : 'Ditolak';
    const time = new Date(d.waktu).toLocaleString('id-ID', { hour: '2-digit', minute: '2-digit' });
    return `<div class="log-card"><div class="log-icon ${cls}">${svg(path)}</div><div class="flex-1 min-w-0"><div class="log-card-top"><span class="log-action ${reject ? 'bad' : pinjam ? 'borrow' : 'return'}">${word}</span><span>${time}</span></div><p class="log-main"><span>${esc(d.user)}</span></p><p class="log-sub">${esc(d.barang)}</p></div></div>`;
  }).join('')}</div></div>`).join('');
}


function penggunaSummaryHtml(rows) {
  const total = rows.length;
  const admin = rows.filter((u) => memberRole(u) === 'admin').length;
  const ketua = rows.filter((u) => memberRole(u) === 'ketua').length;
  const aktif = new Set(pinjamanData.map((p) => p.user)).size;
  return `<div class="team-summary">
    <div><b>${total}</b><span>Anggota</span></div>
    <div><b>${admin}</b><span>Admin</span></div>
    <div><b>${ketua}</b><span>Ketua</span></div>
    <div><b>${aktif}</b><span>Aktif pinjam</span></div>
  </div>`;
}

function renderPenggunaList() {
  const list = $('pengguna-list');
  const empty = $('pengguna-empty');
  if (!list) return;
  if (!usersData.length) { list.innerHTML = ''; empty?.classList.remove('hidden'); return; }
  empty?.classList.add('hidden');
  const colors = ['#0060DF', '#7C3AED', '#059669', '#D97706', '#DB2777', '#0891B2'];
  const manage = canManageUsers();
  const rank = { admin: 0, ketua: 1, teknisi: 2 };
  const sorted = usersData.slice().sort((a, b) => {
    return (rank[memberRole(a)] - rank[memberRole(b)]) || (a.nama || '').localeCompare(b.nama || '', 'id');
  });
  list.innerHTML = penggunaSummaryHtml(sorted) + sorted.map((u, i) => {
    const n = esc(u.nama || '');
    const rl = memberRole(u);
    const hold = pinjamanData.filter((p) => p.user === u.nama).reduce((a, p) => a + num(p.jumlah || 1), 0);
    const btns = manage
      ? `<div class="user-actions"><button onclick="openUserModal('${u.id}')" class="user-edit-btn" title="Edit">${svg('M15.232 5.232l3.536 3.536M9 11l6.232-6.232a2 2 0 012.828 0l.172.172a2 2 0 010 2.828L12 14l-4 1 1-4z','w-5 h-5')}</button><button onclick="hapusPengguna('${u.id}')" class="user-del-btn" title="Hapus">${svg('M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16','w-5 h-5')}</button></div>`
      : '';
    const pill = rl === 'admin' ? 'adm' : rl === 'ketua' ? 'ketua' : 'tek';
    const pillTxt = rl === 'admin' ? 'Admin' : rl === 'ketua' ? 'Ketua Teknisi' : 'Teknisi';
    const bg = rl === 'admin' ? '#0877E8' : rl === 'ketua' ? '#38A8FF' : '#7CCBFF';
    return `<div class="user-card team-card"><div class="team-avatar" style="background:${bg}"><span>${(u.nama || '?')[0].toUpperCase()}</span></div><div class="flex-1 min-w-0"><div class="team-name-row"><p>${n}</p><span class="role-pill ${pill}">${pillTxt}</span></div><div class="team-meta"><span>${hold ? hold + ' barang dipinjam' : 'Tidak ada pinjaman'}</span><span>•</span><span>${rl === 'admin' ? 'Akses penuh' : rl === 'ketua' ? 'Koordinasi tim' : 'Operasional'}</span></div></div>${btns}</div>`;
  }).join('');
}

function canvasJpeg(img, maxDim, quality, crop43) {
  let sw = img.naturalWidth || img.width || 0;
  let sh = img.naturalHeight || img.height || 0;
  if (!sw || !sh) throw new Error('Foto rusak / kosong.');
  let sx = 0, sy = 0, cw = sw, ch = sh;
  if (crop43) {
    const target = 4 / 3;
    const ratio = sw / sh;
    if (ratio > target) { cw = Math.round(sh * target); sx = Math.round((sw - cw) / 2); }
    else if (ratio < target) { ch = Math.round(sw / target); sy = Math.round((sh - ch) / 2); }
  }
  let w = cw, h = ch;
  if (w > maxDim || h > maxDim) {
    if (w > h) { h = Math.round(h * maxDim / w); w = maxDim; }
    else { w = Math.round(w * maxDim / h); h = maxDim; }
  }
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, sx, sy, cw, ch, 0, 0, w, h);
  return c.toDataURL('image/jpeg', quality);
}
function loadImgFromFile(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => resolve({ img, revoke: () => { try { URL.revokeObjectURL(url); } catch (e) {} } });
    img.onerror = () => {
      try { URL.revokeObjectURL(url); } catch (e) {}
      const r = new FileReader();
      r.onerror = () => reject(new Error('Gagal baca foto.'));
      r.onload = (e) => {
        const img2 = new Image();
        img2.onload = () => resolve({ img: img2, revoke: () => {} });
        img2.onerror = () => reject(new Error('Format foto tidak didukung. Ambil ulang sebagai JPG.'));
        img2.src = e.target.result;
      };
      r.readAsDataURL(file);
    };
    img.src = url;
  });
}
function compressImageToDataURL(file, maxDim = 640, quality = 0.72, crop43 = false) {
  return loadImgFromFile(file).then((loaded) => {
    try { return canvasJpeg(loaded.img, maxDim, quality, crop43); }
    finally { try { loaded.revoke(); } catch (e) {} }
  });
}
function previewImage(input) {
  const preview = $('image-preview');
  const ph = $('image-placeholder');
  const hidden = $('edit-image-url');
  if (!input.files || !input.files[0]) { preview.classList.add('hidden'); ph.classList.remove('hidden'); return; }
  const file = input.files[0];
  if (!file.type.startsWith('image/')) { toast('File harus berupa gambar!', 'error'); input.value = ''; return; }
  if (file.size > 8 * 1024 * 1024) { toast('Ukuran file gambar maksimal 8MB!', 'error'); input.value = ''; return; }
  preview.classList.add('hidden'); ph.classList.remove('hidden');
  compressImageToDataURL(file).then((url) => {
    if (url.length > MAX_ITEM_IMAGE_CHARS) { toast('Gambar masih terlalu besar setelah dikompres, coba foto lain.', 'error'); input.value = ''; return; }
    hidden.value = url; preview.src = url; preview.classList.remove('hidden'); ph.classList.add('hidden');
  }).catch((err) => { toast('Gagal memproses gambar: ' + err.message, 'error'); input.value = ''; });
}

function applyPinjamanSnap(snap) {
  const map = {};
  const rows = [];
  snap.forEach((d) => {
    const x = { id: d.id, ...d.data() };
    rows.push(x);
    if (!currentUser.name || x.user === currentUser.name) {
      map[x.barangId] = (map[x.barangId] || 0) + (x.jumlah || 1);
    }
  });
  pinjamanData = rows;
  userPinjamanMap = canPinjam() ? map : {};
  renderGudangList();
  if (isStaff()) renderPenggunaList();
  if ($('pinjam-board') && !$('pinjam-board').classList.contains('hidden')) renderPinjamBoard();
  syncAlarmsSoon();
}
function attachPinjamanListener(username) {
  stop('pinjam');
  if (!username) {
    userPinjamanMap = {};
    pinjamanData = [];
    updateKpis();
    renderGudangList();
    return;
  }
  const q = username === '*'
    ? db.collection('pinjaman')
    : db.collection('pinjaman').where('user', '==', username);
  unsub.pinjam = q.onSnapshot((snap) => applyPinjamanSnap(snap), (e) => toast('Gagal memuat data pinjaman: ' + e.message, 'error'));
}
function attachUsersListener() {
  stop('users');
  unsub.users = db.collection('users').onSnapshot((snap) => {
    usersData = []; snap.forEach((d) => usersData.push({ id: d.id, ...d.data() }));
    renderPenggunaList();
    renderAbsenList();
    renderHub();
    syncMemberRole();
  }, (e) => toast('Gagal memuat akun teknisi: ' + e.message, 'error'));
}
function phoneNotify(title, body) {
  try {
    if (window.SkaliskaNotify && typeof window.SkaliskaNotify.notify === 'function') {
      window.SkaliskaNotify.notify(String(title || ''), String(body || ''));
      return;
    }
  } catch (e) {}
  try {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      new Notification(title, { body: body, silent: false });
    }
  } catch (e) {}
}
function askNotifPerm() {
  try {
    if (localStorage.getItem('sk_asked_notif') === '1') return;
    localStorage.setItem('sk_asked_notif', '1');
  } catch (e) {}
  try {
    if (window.SkaliskaNotify && typeof window.SkaliskaNotify.askPermission === 'function') {
      window.SkaliskaNotify.askPermission();
    }
  } catch (e) {}
  try {
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') Notification.requestPermission();
  } catch (e) {}
}
function attachReturnNotifyListener() {
  if (unsub.reqNotify) return;
  let primed = false;
  unsub.reqNotify = db.collection('return_requests').onSnapshot((snap) => {
    if (!primed) { primed = true; return; }
    if (!isStaff()) return;
    snap.docChanges().forEach((ch) => {
      if (ch.type !== 'added') return;
      const x = ch.doc.data() || {};
      if (x.status && x.status !== 'pending') return;
      if (x.user && x.user === currentUser.name) return;
      phoneNotify('Pengajuan pengembalian', (x.user || 'Teknisi') + ' ingin mengembalikan ' + (x.barangNama || 'barang'));
    });
  }, () => {});
}
function attachAnnounceNotifyListener() {
  if (unsub.annNotify) return;
  let primed = false;
  unsub.annNotify = db.collection('pengumuman').onSnapshot((snap) => {
    if (!primed) { primed = true; return; }
    snap.docChanges().forEach((ch) => {
      if (ch.type !== 'added') return;
      const x = ch.doc.data() || {};
      if (x.by && x.by === currentUser.name) return;
      const teks = String(x.teks || '').trim();
      phoneNotify('Pengumuman baru', (x.by || 'Admin') + (teks ? ': ' + teks.slice(0, 90) : ''));
    });
  }, () => {});
}
function attachRequestsListener() {
  stop('req');
  unsub.req = db.collection('return_requests').onSnapshot((snap) => {
    pendingRequests = [];
    snap.forEach((d) => { const x = d.data(); if (!x.status || x.status === 'pending') pendingRequests.push({ id: d.id, ...x }); });
    renderRiwayatList();
    renderHub();
  }, (e) => toast('Gagal memuat permintaan pengembalian: ' + e.message, 'error'));
}
function attachMyReturnRequestsListener(username) {
  stop('myReq');
  if (!username) { userPendingReturnMap = {}; renderGudangList(); return; }
  unsub.myReq = db.collection('return_requests').where('user', '==', username).onSnapshot((snap) => {
    const map = {};
    snap.forEach((d) => { const x = d.data(); if (x.status === 'pending') map[x.barangId] = true; });
    userPendingReturnMap = map;
    renderGudangList();
    if ($('pinjam-board') && !$('pinjam-board').classList.contains('hidden')) renderPinjamBoard();
    if (itemSheetId && $('item-modal') && !$('item-modal').classList.contains('hidden')) openItemSheet(itemSheetId);
  }, (e) => toast('Gagal memuat status pengembalian: ' + e.message, 'error'));
}
function attachGudangListener() {
  if (unsub.gudang) return;
  unsub.gudang = db.collection('gudang').onSnapshot((snap) => {
    gudangData = [];
    snap.forEach((d) => {
      const x = { id: d.id, ...d.data() };
      x.stok = num(x.stok);
      x.img = itemImage(d.id, x.imageUrl || '');
      gudangData.push(x);
    });
    renderGudangList();
    if (itemSheetId) {
      const still = gudangData.some((b) => b.id === itemSheetId);
      if (still && $('item-modal') && !$('item-modal').classList.contains('hidden')) openItemSheet(itemSheetId);
    }
  }, (e) => toast('Gagal memuat data barang: ' + e.message, 'error'));
}
function attachRiwayatListener() {
  if (unsub.riwayat) return;
  unsub.riwayat = db.collection('riwayat').orderBy('waktu', 'desc').limit(RIWAYAT_LIMIT).onSnapshot((snap) => {
    riwayatData = []; snap.forEach((d) => riwayatData.push(d.data()));
    renderRiwayatList();
  }, () => {
    stop('riwayat');
    unsub.riwayat = db.collection('riwayat').onSnapshot((snap) => {
      const rows = []; snap.forEach((d) => rows.push(d.data()));
      rows.sort((a, b) => (b.waktu || 0) - (a.waktu || 0));
      riwayatData = rows.slice(0, RIWAYAT_LIMIT);
      renderRiwayatList();
    }, (e) => toast('Gagal memuat riwayat: ' + e.message, 'error'));
  });
}

function applyChrome() {
  const admin = isAdmin();
  const staff = isStaff();
  if ($('user-display-name')) $('user-display-name').textContent = currentUser.name;
  if ($('user-role-badge')) $('user-role-badge').textContent = roleLabel(currentUser.role);
  if ($('btn-add')) { $('btn-add').classList.toggle('hidden', !admin); $('btn-add').style.display = admin ? 'flex' : 'none'; }
  if ($('nav-pengguna')) $('nav-pengguna').classList.toggle('hidden', !staff);
  if ($('btn-settings')) { $('btn-settings').classList.toggle('hidden', !admin); $('btn-settings').style.display = admin ? 'flex' : 'none'; }
  if ($('btn-clear-log')) $('btn-clear-log').style.display = admin ? 'flex' : 'none';
  const ex = $('btn-export-log'); if (ex) ex.style.display = staff ? 'flex' : 'none';
  if ($('btn-add-user')) $('btn-add-user').style.display = admin ? 'flex' : 'none';
  if ($('pengguna-title')) $('pengguna-title').textContent = admin ? 'Kelola Teknisi' : 'Anggota Tim';
  if ($('announce-composer')) $('announce-composer').classList.toggle('hidden', !staff);
  if ($('btn-reset-absen')) $('btn-reset-absen').style.display = staff ? 'flex' : 'none';
  if ($('btn-export-absen')) $('btn-export-absen').style.display = staff ? 'flex' : 'none';
}
function bindRoleListeners() {
  attachGudangListener();
  attachReturnNotifyListener();
  attachAnnounceNotifyListener();
  attachAnnounceListener();
  setTimeout(askNotifPerm, 2500);
  if (isStaff()) {
    attachPinjamanListener('*');
    attachUsersListener();
    attachRequestsListener();
    attachRiwayatListener();
  } else {
    attachPinjamanListener(currentUser.name);
  }
  if (canPinjam()) attachMyReturnRequestsListener(currentUser.name);
  else attachMyReturnRequestsListener(null);
  fillAbsenPeriod();
  attachAbsenListener();
}
function syncMemberRole() {
  if (isAdmin() || !currentUser.name) return;
  const me = usersData.find((u) => u.nama === currentUser.name);
  if (!me) return;
  const r = roleFromDoc(me);
  if (r === currentUser.role) return;
  currentUser.role = r;
  try { localStorage.setItem('sk_ses', JSON.stringify({ n: currentUser.name, r })); } catch (e) {}
  applyChrome();
  bindRoleListeners();
  lastGudangSig = '';
  renderGudangList();
  renderAbsenList();
  toast('Role kamu sekarang: ' + roleLabel(r), 'info');
}
function loginSuccess(name, role, quiet) {
  // v68: UI transition must not be blocked by Firestore listeners.
  currentUser = { name, role };
  try { localStorage.setItem('sk_ses', JSON.stringify({ n: name, r: role })); localStorage.setItem('sk_user', name === 'Admin Utama' ? 'min' : name); } catch (e) {}

  // Show the app FIRST. If database/listener has a runtime/network issue, login still succeeds and UI opens.
  try { $('login-view')?.classList.add('hidden'); } catch (e) {}
  try { $('app-view')?.classList.remove('hidden'); } catch (e) {}
  try { document.body.classList.add('is-in'); } catch (e) {}
  try { hideBoot(); } catch (e) {}
  try { $('username') && ($('username').value = ''); } catch (e) {}
  try { $('password') && ($('password').value = ''); } catch (e) {}
  try { $('password-container')?.classList.remove('hidden'); } catch (e) {}
  try { $('login-error')?.classList.add('hidden'); } catch (e) {}

  try { applyChrome(); } catch (e) { console.warn('applyChrome failed:', e && e.message ? e.message : e); }
  try { if (typeof updateTopAccount === 'function') updateTopAccount(); } catch (e) {}
  try { if (typeof wirePlexUi === 'function') wirePlexUi(); } catch (e) {}
  try { switchTab('gudang'); } catch (e) { console.warn('switchTab failed:', e && e.message ? e.message : e); }

  // Attach Firebase listeners AFTER screen transition; never throw into login handler.
  setTimeout(() => {
    try { bindRoleListeners(); }
    catch (e) {
      console.warn('bindRoleListeners failed:', e && e.message ? e.message : e);
      toast('Login berhasil, sinkron database sedang dicoba ulang.', 'warning');
      setTimeout(() => { try { bindRoleListeners(); } catch (_) {} }, 1500);
    }
  }, 0);

  if (!quiet) toast('Selamat datang, ' + esc(name) + '!', 'success');
  setTimeout(queueFlush, 700);
  setTimeout(syncAlarms, 1200);
}

function restVal(fields, k) {
  const v = (fields || {})[k] || {};
  return v.stringValue ?? v.integerValue ?? v.doubleValue ?? v.booleanValue ?? '';
}
function userFromRestDoc(doc) {
  const f = doc.fields || {};
  return { id: (doc.name || '').split('/').pop(), nama: restVal(f, 'nama'), password: restVal(f, 'password'), role: restVal(f, 'role'), createdAt: restVal(f, 'createdAt') };
}
async function getUserByNameRobust(user) {
  const wanted = String(user || '').trim();
  if (!wanted) return null;
  // 1) Firestore SDK server query (normal path)
  try {
    const snap = await withTimeout(db.collection('users').where('nama', '==', wanted).get({ source: 'server' }), 9000, 'Timeout server users');
    if (snap && !snap.empty) return { id: snap.docs[0].id, ...snap.docs[0].data() };
  } catch (e) { console.warn('SDK server login query failed:', e && e.message ? e.message : e); }
  // 2) Firestore SDK default/cache query
  try {
    const snap = await withTimeout(db.collection('users').where('nama', '==', wanted).get(), 9000, 'Timeout users');
    if (snap && !snap.empty) return { id: snap.docs[0].id, ...snap.docs[0].data() };
  } catch (e) { console.warn('SDK login query failed:', e && e.message ? e.message : e); }
  // 3) REST fallback. This protects preview/browser when SDK persistence/cache is stuck.
  try {
    const endpoint = 'https://firestore.googleapis.com/v1/projects/' + encodeURIComponent(firebaseConfig.projectId) + '/databases/(default)/documents:runQuery?key=' + encodeURIComponent(firebaseConfig.apiKey);
    const body = {
      structuredQuery: {
        from: [{ collectionId: 'users' }],
        where: { fieldFilter: { field: { fieldPath: 'nama' }, op: 'EQUAL', value: { stringValue: wanted } } },
        limit: 1
      }
    };
    const res = await withTimeout(fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }), 10000, 'Timeout REST users');
    if (res && res.ok) {
      const arr = await res.json();
      const doc = (arr || []).map((x) => x.document).find(Boolean);
      if (doc && doc.fields) return userFromRestDoc(doc);
    } else {
      console.warn('REST login query HTTP', res && res.status);
    }
  } catch (e) { console.warn('REST login query failed:', e && e.message ? e.message : e); }

  // 4) REST list fallback + case-insensitive trim match. This fixes login when user types Tes/extra spaces
  // or Firestore query index/cache is stuck in preview.
  try {
    const listUrl = 'https://firestore.googleapis.com/v1/projects/' + encodeURIComponent(firebaseConfig.projectId) + '/databases/(default)/documents/users?pageSize=100&key=' + encodeURIComponent(firebaseConfig.apiKey);
    const res = await withTimeout(fetch(listUrl), 10000, 'Timeout REST list users');
    if (res && res.ok) {
      const data = await res.json();
      const wantedLower = wanted.toLowerCase();
      const doc = (data.documents || []).find((d) => String(restVal(d.fields || {}, 'nama') || '').trim().toLowerCase() === wantedLower);
      if (doc) return userFromRestDoc(doc);
    }
  } catch (e) { console.warn('REST list users failed:', e && e.message ? e.message : e); }
  return null;
}
function showLoginErr(msg) {
  const err = $('login-error');
  if (err) { err.textContent = msg; err.classList.remove('hidden'); }
}

async function handleLogin() {
  try {
    const user = ($('username')?.value || '').trim();
    const pass = ($('password')?.value || '').trim();
    const err = $('login-error');
    if (err) err.classList.add('hidden');
    if (!user) { showLoginErr('Isi username dulu.'); verifyDbConnection && verifyDbConnection(); return; }
    if (!pass) { showLoginErr('Isi password dulu.'); return; }
    setBusy('btn-login', true, LOGIN_BTN);
    if (typeof setDbStatus === 'function') setDbStatus('checking', 'Menghubungkan database...');

    // Admin shortcut and DB user both supported.
    if (user.toLowerCase() === 'min' && pass === 'aezakmi') {
      if (typeof setDbStatus === 'function') setDbStatus('ok', 'Database online');
      loginSuccess('Admin Utama', 'admin');
      return;
    }

    const udata = await getUserByNameRobust(user);
    if (!udata) {
      showLoginErr('Username tidak terdaftar atau database belum merespons.');
      if (typeof setDbStatus === 'function') setDbStatus('bad', 'User tidak ditemukan');
      return;
    }
    if (String(udata.password || '') !== pass) {
      showLoginErr('Password salah. Coba lagi.');
      if (typeof setDbStatus === 'function') setDbStatus('ok', 'Database online');
      haptic([50, 50, 50]);
      return;
    }
    if (typeof setDbStatus === 'function') setDbStatus('ok', 'Database online');
    loginSuccess(udata.nama || user, roleFromDoc(udata));
  } catch (e) {
    showLoginErr('Login gagal: ' + (e && e.message ? e.message : e));
    if (typeof setDbStatus === 'function') setDbStatus('bad', 'Login/database error');
    toast('Error login: ' + (e && e.message ? e.message : e), 'error');
  } finally {
    setBusy('btn-login', false, LOGIN_BTN);
  }
}
async function requestLogout() {
  if (!(await ask('Keluar dari akun ini?', 'Hanya keluar jika kamu tekan tombol ini. Tutup aplikasi tidak membuat akun terlepas.', 'Keluar'))) return;
  handleLogout();
}
function handleLogout() {
  Object.keys(unsub).forEach(stop);
  userPinjamanMap = {}; userPendingReturnMap = {}; usersData = []; pendingRequests = [];
  gudangData = []; riwayatData = []; pinjamanData = []; absenData = []; announceData = []; absenFocus = ''; lastGudangSig = ''; lastCatSig = ''; processingIds.clear();
  currentUser = { name: '', role: '' };
  itemSheetId = '';
  try { localStorage.removeItem('sk_ses'); } catch (e) {}
  clearBlobs();
  const gl = $('gudang-list'); if (gl) gl.innerHTML = '';
  document.body.classList.remove('is-in');
  $('login-view').classList.remove('hidden');
  $('app-view').classList.add('hidden');
  hideBoot();
  closeItemSheet();
  closePinjamBoard();
  closeReturnSheet();
  setDashCompact(false);
  lastScrollY = 0;
}
let dashCompact = false;
let lastScrollY = 0;
function setDashCompact(on) {
  if (dashCompact === on) return;
  dashCompact = on;
  const h = $('dash-header');
  if (h) h.classList.toggle('is-compact', on);
}
function syncDashDot() {
  const dot = $('dash-dot');
  if (!dot) return;
  const show = isStaff() && pendingRequests.length > 0;
  dot.classList.toggle('hidden', !show);
}
function switchTab(tab) {
  ['gudang', 'riwayat', 'pengguna', 'absen'].forEach((t) => {
    const view = $(`${t}-view`); const nav = $(`nav-${t}`);
    if (!view || !nav) return;
    view.classList.toggle('hidden', t !== tab);
    nav.classList.toggle('active', t === tab);
  });
  const main = document.querySelector('.main-scroll-area');
  if (main) main.scrollTop = 0;
  if (tab === 'riwayat') attachRiwayatListener();
  if (tab === 'absen') { attachAbsenListener(); renderAbsenList(); }
  haptic(8);
}

function openBarangModal(id = '') {
  if (!canEditStock()) return;
  const item = id ? gudangData.find((b) => b.id === id) : null;
  $('edit-id').value = id;
  $('edit-nama').value = item ? item.nama : '';
  $('edit-stok').value = item ? String(num(item.stok)) : '0';
  $('edit-kategori').value = item ? (item.kategori || 'Jaringan') : 'Jaringan';
  $('edit-lokasi').value = item ? (item.lokasi || '') : '';
  if ($('edit-seri')) $('edit-seri').value = item ? (item.seri || '') : '';
  if ($('edit-kondisi')) $('edit-kondisi').value = item ? kondisiOf(item) : 'baik';
  $('edit-image').value = '';
  $('edit-image-url').value = (item && item.imageUrl) || '';
  const preview = $('image-preview'); const ph = $('image-placeholder');
  const src = item && (item.img || item.imageUrl);
  if (src) { preview.src = src; preview.classList.remove('hidden'); ph.classList.add('hidden'); }
  else { preview.removeAttribute('src'); preview.classList.add('hidden'); ph.classList.remove('hidden'); }
  $('modal-title').textContent = id ? 'Edit Barang' : 'Tambah Barang Baru';
  const del = $('modal-delete-btn');
  if (id) { del.classList.remove('hidden'); del.setAttribute('data-delete-id', id); del.setAttribute('data-delete-nama', item ? item.nama : ''); }
  else del.classList.add('hidden');
  $('admin-modal').classList.remove('hidden');
}
function closeBarangModal() { $('admin-modal').classList.add('hidden'); }
async function saveBarang() {
  if (!canEditStock()) return;
  const id = $('edit-id').value;
  const nama = $('edit-nama').value.trim();
  const stok = num($('edit-stok').value);
  const kategori = $('edit-kategori').value;
  const lokasi = $('edit-lokasi').value.trim() || '-';
  const seri = ($('edit-seri')?.value || '').trim();
  const kondisi = ($('edit-kondisi')?.value || 'baik');
  const imageUrl = $('edit-image-url').value || '';
  if (!nama || stok < 0 || $('edit-stok').value === '') { toast('Cek nama & stok!', 'warning'); return; }
  if (imageUrl.length > MAX_ITEM_IMAGE_CHARS) { toast('Gambar terlalu besar, pilih foto lain.', 'error'); return; }
  setBusy('btn-save-modal', true, 'Simpan');
  try {
    const payload = { nama, stok, kategori, lokasi, seri, kondisi, imageUrl };
    if (id) await db.collection('gudang').doc(id).update(payload);
    else await db.collection('gudang').add(payload);
    toast('Tersimpan!', 'success');
    closeBarangModal();
  } catch (e) { toast(e.message || 'Gagal simpan.', 'error'); }
  finally { setBusy('btn-save-modal', false, 'Simpan'); }
}
async function hapusBarang(id, nama) {
  if (!canEditStock()) return;
  if (!(await ask('Hapus ' + esc(nama) + '?', 'Barang dihapus dari gudang.', 'Hapus'))) return;
  try { await db.collection('gudang').doc(id).delete(); toast('Barang dihapus.', 'success'); }
  catch (e) { toast('Gagal hapus.', 'error'); }
}
async function hapusDariModal() {
  const btn = $('modal-delete-btn');
  closeBarangModal();
  await hapusBarang(btn.getAttribute('data-delete-id'), btn.getAttribute('data-delete-nama'));
}

function openUserModal(id = '') {
  if (!canManageUsers()) return;
  editUserId = id || '';
  const u = id ? usersData.find((x) => x.id === id) : null;
  $('edit-user-id').value = editUserId;
  $('new-user-nama').value = u ? (u.nama || '') : '';
  $('new-user-password').value = '';
  if ($('new-user-role')) $('new-user-role').value = memberRole(u);
  const title = $('user-modal-title');
  const sub = $('user-modal-sub');
  const hint = $('user-pass-hint');
  const btn = $('btn-save-user');
  if (u) {
    if (title) title.textContent = 'Edit Teknisi';
    if (sub) sub.textContent = 'Ubah nama, password, atau role';
    if (hint) hint.textContent = 'Kosongkan password jika tidak diganti.';
    if (btn) btn.lastChild ? btn.lastChild.textContent = ' Simpan' : null;
  } else {
    if (title) title.textContent = 'Tambah Teknisi';
    if (sub) sub.textContent = 'Daftarkan akun baru';
    if (hint) hint.textContent = 'Simpan baik-baik, tidak bisa dilihat lagi.';
  }
  $('user-modal').classList.remove('hidden');
  setTimeout(() => $('new-user-nama').focus(), 200);
}
function closeUserModal() { $('user-modal').classList.add('hidden'); editUserId = ''; }
async function saveUser() {
  if (!canManageUsers()) return;
  const id = $('edit-user-id').value || editUserId;
  const nama = $('new-user-nama').value.trim();
  const password = $('new-user-password').value.trim();
  const rawRole = $('new-user-role')?.value;
  const role = rawRole === 'admin' ? 'admin' : rawRole === 'ketua' ? 'ketua' : 'teknisi';
  if (!nama || nama.length < 2) { toast('Nama min 2 karakter!', 'warning'); return; }
  if (nama.toLowerCase() === 'min') { toast('"min" reserved untuk Admin!', 'error'); return; }
  if (!id && (!password || password.length < 4)) { toast('Password min 4 karakter!', 'warning'); return; }
  if (id && password && password.length < 4) { toast('Password min 4 karakter!', 'warning'); return; }
  const html = svg('M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z') + (id ? 'Simpan' : 'Daftarkan');
  setBusy('btn-save-user', true, html);
  try {
    const dup = await db.collection('users').where('nama', '==', nama).get();
    const clash = dup.docs.some((d) => d.id !== id);
    if (clash) { toast('"' + nama + '" sudah terdaftar!', 'error'); setBusy('btn-save-user', false, html); return; }
    if (id) {
      const payload = { nama, role };
      if (password) payload.password = password;
      await db.collection('users').doc(id).update(payload);
      toast('Akun "' + esc(nama) + '" · ' + roleLabel(role === 'teknisi' ? 'user' : role) + ' disimpan.', 'success');
    } else {
      await db.collection('users').add({ nama, password, role, createdAt: Date.now() });
      toast(roleLabel(role === 'teknisi' ? 'user' : role) + ' "' + esc(nama) + '" didaftarkan!', 'success');
    }
    closeUserModal();
  } catch (e) { toast('Gagal: ' + e.message, 'error'); }
  finally { setBusy('btn-save-user', false, html); }
}
async function hapusPengguna(id) {
  if (!canManageUsers()) return;
  const u = usersData.find((x) => x.id === id);
  const nama = u ? u.nama : 'akun ini';
  if (!(await ask('Hapus akun "' + esc(nama) + '"?', 'Teknisi tidak bisa login setelah dihapus.', 'Hapus'))) return;
  try { await db.collection('users').doc(id).delete(); toast('Akun "' + esc(nama) + '" dihapus.', 'success'); }
  catch (e) { toast('Gagal hapus: ' + e.message, 'error'); }
}

function ymKey(y, m) {
  return String(y || absenYear) + '-' + String(m || absenMonth).padStart(2, '0');
}
function absenJenis(a) {
  if (!a) return 'hadir';
  if (a.jenis === 'izin' || a.jenis === 'sakit' || a.jenis === 'hadir') return a.jenis;
  if (a.status === 'izin') return 'izin';
  if (a.status === 'sakit') return 'sakit';
  return 'hadir';
}
function absenOk(a) { return !a.status || a.status === 'ok' || a.status === 'izin' || a.status === 'sakit'; }
function absenPend(a) { return a.status === 'pending'; }
function absenHadir(a) { return absenOk(a) && absenJenis(a) === 'hadir'; }
function fillAbsenPeriod() {
  const sel = $('absen-bulan');
  const yr = $('absen-tahun');
  if (sel && !sel.options.length) {
    sel.innerHTML = BLN.map((n, i) => `<option value="${i + 1}">${n}</option>`).join('');
  }
  if (sel) sel.value = String(absenMonth);
  if (yr) yr.value = String(absenYear);
}
function changeAbsenPeriod() {
  absenMonth = num($('absen-bulan')?.value) || absenMonth;
  absenYear = num($('absen-tahun')?.value) || absenYear;
  if (absenYear < 2020) absenYear = 2020;
  attachAbsenListener();
  renderAbsenList();
  if (absenFocus) renderAbsenCal(absenFocus, 'absen-days', true);
}
function attachAbsenListener() {
  stop('absen');
  unsub.absen = db.collection('absen').where('ym', '==', ymKey()).onSnapshot((snap) => {
    absenData = [];
    snap.forEach((d) => absenData.push({ id: d.id, ...d.data() }));
    renderAbsenList();
    if (absenFocus) renderAbsenCal(absenFocus, 'absen-days', true);
  }, () => {
    stop('absen');
    unsub.absen = db.collection('absen').onSnapshot((snap) => {
      const key = ymKey();
      absenData = [];
      snap.forEach((d) => { const x = { id: d.id, ...d.data() }; if (x.ym === key) absenData.push(x); });
      renderAbsenList();
      if (absenFocus) renderAbsenCal(absenFocus, 'absen-days', true);
    }, (e) => toast('Gagal memuat absen: ' + e.message, 'error'));
  });
}
function absenMembers() {
  if (isStaff()) return usersData.slice();
  return [{ id: 'me', nama: currentUser.name }];
}
function absenOf(nama) { return absenData.filter((a) => a.nama === nama); }
function absenCount(nama) { return absenOf(nama).filter(absenHadir).length; }
function avatarHtml(nama, i, size) {
  const colors = ['#0060DF', '#7C3AED', '#059669', '#D97706', '#DB2777', '#0891B2'];
  const sz = size || 'w-11 h-11';
  return `<div class="${sz} rounded-2xl flex items-center justify-center shrink-0" style="background:${colors[i % colors.length]}"><span class="text-white font-black text-base">${(nama[0] || '?').toUpperCase()}</span></div>`;
}
function ghCalendarHtml(nama) {
  const first = new Date(absenYear, absenMonth - 1, 1);
  const days = new Date(absenYear, absenMonth, 0).getDate();
  const pad = first.getDay();
  const todayStr = todayKey();
  const map = {};
  absenOf(nama).forEach((a) => { map[a.tgl] = a; });
  const heads = ['Min','Sen','Sel','Rab','Kam','Jum','Sab'].map((h) => `<span>${h}</span>`).join('');
  let cells = '';
  for (let i = 0; i < pad; i++) cells += '<div class="gh-cell pad"></div>';
  for (let d = 1; d <= days; d++) {
    const tgl = absenYear + '-' + String(absenMonth).padStart(2, '0') + '-' + String(d).padStart(2, '0');
    const rec = map[tgl];
    const future = tgl > todayStr;
    let cls = 'gh-cell';
    if (rec && absenPend(rec)) cls += ' pending';
    else if (rec && absenJenis(rec) === 'izin') cls += ' izin';
    else if (rec && absenJenis(rec) === 'sakit') cls += ' sakit';
    else if (rec && absenHadir(rec)) cls += (d % 3 === 0 ? ' ok-deep' : ' ok');
    if (tgl === todayStr) cls += ' today';
    if (future) cls += ' future';
    const enc = encodeURIComponent(nama);
    cells += `<button type="button" class="${cls}" onclick="tapAbsenDay(decodeURIComponent('${enc}'),'${tgl}')"><span class="gh-num">${d}</span></button>`;
  }
  return `<div class="gh-weekdays">${heads}</div><div class="gh-cal">${cells}</div>
    <div class="gh-legend">
      <span>Kosong</span><i class="sw" style="background:#ebedf0"></i>
      <span>Ajuan</span><i class="sw" style="background:#fbbf24"></i>
      <span>Hadir</span><i class="sw" style="background:#40c463"></i>
      <span>Izin</span><i class="sw" style="background:#58a6ff"></i>
      <span>Sakit</span><i class="sw" style="background:#f97316"></i>
    </div>`;
}
function ghMiniHtml(nama) {
  const days = new Date(absenYear, absenMonth, 0).getDate();
  const map = {};
  absenOf(nama).forEach((a) => { map[Number(String(a.tgl).slice(-2))] = a; });
  let html = '';
  for (let d = 1; d <= days; d++) {
    const rec = map[d];
    let cls = '';
    if (rec && absenPend(rec)) cls = 'pending';
    else if (rec && absenJenis(rec) === 'izin') cls = 'izin';
    else if (rec && absenJenis(rec) === 'sakit') cls = 'sakit';
    else if (rec && absenHadir(rec)) cls = 'ok';
    html += `<i class="${cls}"></i>`;
  }
  return `<div class="gh-mini">${html}</div>`;
}

function absenSummaryHtml(nama) {
  const mine = absenOf(nama);
  const hadir = mine.filter(absenHadir).length;
  const izin = mine.filter((a) => absenOk(a) && absenJenis(a) === 'izin').length;
  const sakit = mine.filter((a) => absenOk(a) && absenJenis(a) === 'sakit').length;
  const pending = mine.filter(absenPend).length;
  return `<div class="absen-summary-grid">
    <div class="absen-stat good"><b>${hadir}</b><span>Hadir</span></div>
    <div class="absen-stat blue"><b>${izin}</b><span>Izin</span></div>
    <div class="absen-stat orange"><b>${sakit}</b><span>Sakit</span></div>
    <div class="absen-stat wait"><b>${pending}</b><span>Ajuan</span></div>
  </div>`;
}

function renderAbsenList() {
  const list = $('absen-list');
  const empty = $('absen-empty');
  if (!list) return;
  fillAbsenPeriod();
  syncAlarmsSoon();
  const admin = isStaff();
  const members = absenMembers().sort((a, b) => (a.nama || '').localeCompare(b.nama || '', 'id'));
  renderAbsenRekap();
  renderHub();
  if (admin && !members.length) { list.innerHTML = ''; empty?.classList.remove('hidden'); return; }
  empty?.classList.add('hidden');
  if (!admin) {
    const n = currentUser.name;
    const c = absenCount(n);
    const mine = absenOf(n);
    const iz = mine.filter((a) => absenOk(a) && absenJenis(a) === 'izin').length;
    const sk = mine.filter((a) => absenOk(a) && absenJenis(a) === 'sakit').length;
    const extra = (iz || sk) ? `<p class="text-[11px] font-bold c-text-3 mt-1">${iz} izin · ${sk} sakit</p>` : '';
    list.innerHTML = `<div class="absen-me">
      <div class="absen-me-head">${avatarHtml(n, 0, 'w-14 h-14')}
        <div class="flex-1 min-w-0"><p class="font-black text-lg truncate">${esc(n)}</p><p class="text-[10px] font-bold uppercase tracking-widest c-text-3 mt-1">${BLN[absenMonth - 1]} ${absenYear}</p>${extra}</div>
        <div class="absen-badge">Hadir<small>${c}</small></div>
      </div>
      ${absenSummaryHtml(n)}
      ${ghCalendarHtml(n)}
      <p class="gh-hint">Tap tanggal untuk isi kehadiran. Warna membantu lihat status harian dengan cepat.</p>
    </div>`;
    return;
  }
  list.innerHTML = `<div class="absen-admin-list">${members.map((u, i) => {
    const n = u.nama || '';
    const c = absenCount(n);
    const pend = absenOf(n).filter(absenPend).length;
    const iz = absenOf(n).filter((a) => absenOk(a) && absenJenis(a) === 'izin').length;
    const sk = absenOf(n).filter((a) => absenOk(a) && absenJenis(a) === 'sakit').length;
    const tags = [
      pend ? `<span class="text-[10px] font-black" style="color:#B45309">${pend} ajuan</span>` : '',
      iz ? `<span class="text-[10px] font-black" style="color:#2563EB">${iz} izin</span>` : '',
      sk ? `<span class="text-[10px] font-black" style="color:#C2410C">${sk} sakit</span>` : ''
    ].filter(Boolean).join(' ');
    return `<button type="button" class="absen-bar" onclick="openAbsenModal(decodeURIComponent('${encodeURIComponent(n)}'))">
      ${avatarHtml(n, i)}
      <div class="flex-1 min-w-0"><p class="font-black text-[15px] truncate">${esc(n)}</p><div class="absen-bar-meta"><span>${BLN[absenMonth - 1]} ${absenYear}</span>${tags ? `<span class="absen-tags">${tags}</span>` : ''}</div>${ghMiniHtml(n)}</div>
      <div class="absen-badge">Hadir<small>${c}</small></div>
    </button>`;
  }).join('')}</div>`;
}
function openAbsenModal(nama) {
  if (!isStaff()) return;
  absenFocus = nama;
  const ini = $('absen-modal-initial');
  if (ini) ini.textContent = (nama[0] || '?').toUpperCase();
  if ($('absen-modal-title')) $('absen-modal-title').textContent = nama;
  if ($('absen-modal-sub')) $('absen-modal-sub').textContent = BLN[absenMonth - 1] + ' ' + absenYear;
  renderAbsenCal(nama, 'absen-days', true);
  if ($('btn-reset-absen-orang')) $('btn-reset-absen-orang').classList.remove('hidden');
  $('absen-modal').classList.remove('hidden');
}
function closeAbsenModal() { $('absen-modal')?.classList.add('hidden'); absenFocus = ''; }
function renderAbsenCal(nama, hostId) {
  const box = $(hostId);
  if (!box) return;
  box.innerHTML = ghCalendarHtml(nama);
}
function pickAbsenKind(title) {
  return new Promise((resolve) => {
    absenTypeResolve = resolve;
    if ($('absen-type-title')) $('absen-type-title').textContent = title || 'Pilih jenis';
    $('absen-type-modal')?.classList.remove('hidden');
  });
}
function pickAbsenType(k) {
  $('absen-type-modal')?.classList.add('hidden');
  if (absenTypeResolve) {
    const fn = absenTypeResolve;
    absenTypeResolve = null;
    fn(k || '');
  }
}
async function tapAbsenDay(nama, tgl) {
  if (tgl > todayKey()) { toast('Belum bisa absen di tanggal depan.', 'warning'); return; }
  const rec = absenOf(nama).find((a) => a.tgl === tgl);
  const admin = isStaff();
  if (!admin) {
    if (nama !== currentUser.name) return;
    if (rec && absenOk(rec)) { toast('Tanggal ini sudah tercatat.', 'info'); return; }
    if (rec && absenPend(rec)) { toast('Ajuan masih menunggu admin.', 'info'); return; }
    const jenis = await pickAbsenKind('Ajukan ' + tgl);
    if (!jenis) return;
    const payload = { nama, tgl, ym: ymFromTgl(tgl) || ymKey(), waktu: Date.now(), by: currentUser.name, status: 'pending', jenis };
    try {
      await db.collection('absen').add(payload);
      toast('Ajuan ' + jenis + ' dikirim. Menunggu admin.', 'info');
    } catch (e) {
      if (isNetErr(e)) enqueue('absen', payload);
      else toast('Gagal: ' + e.message, 'error');
    }
    return;
  }
  if (rec && absenPend(rec)) { await setujuiAbsen(rec.id); return; }
  if (rec && absenOk(rec)) {
    if (!(await ask('Hapus catatan tanggal ' + tgl + '?', 'Hadir / izin / sakit tanggal ini dihapus.', 'Hapus'))) return;
    try { await db.collection('absen').doc(rec.id).delete(); toast('Catatan dihapus.', 'success'); }
    catch (e) { toast('Gagal hapus.', 'error'); }
    return;
  }
  const jenis = await pickAbsenKind('Tandai ' + tgl);
  if (!jenis) return;
  const status = jenis === 'hadir' ? 'ok' : jenis;
  try {
    await db.collection('absen').add({ nama, tgl, ym: ymFromTgl(tgl) || ymKey(), waktu: Date.now(), by: currentUser.name, status, jenis });
    toast(jenis === 'hadir' ? 'Ditandai hadir.' : 'Ditandai ' + jenis + '.', 'success');
  } catch (e) { toast('Gagal: ' + e.message, 'error'); }
}
async function setujuiAbsen(id) {
  if (!isStaff()) return;
  const rec = absenData.find((a) => a.id === id);
  const jenis = rec ? absenJenis(rec) : 'hadir';
  const status = jenis === 'hadir' ? 'ok' : jenis;
  try {
    await db.collection('absen').doc(id).update({ status, jenis, approvedBy: currentUser.name, approvedAt: Date.now() });
    toast(jenis === 'hadir' ? 'Absen disetujui.' : (jenis.charAt(0).toUpperCase() + jenis.slice(1) + ' disetujui.'), 'success');
  } catch (e) { toast('Gagal: ' + e.message, 'error'); }
}
async function hapusAbsen(id) {
  if (!isStaff()) return;
  if (!(await ask('Hapus absen ini?', 'Catatan tanggal tersebut dihapus.', 'Hapus'))) return;
  try { await db.collection('absen').doc(id).delete(); toast('Absen dihapus.', 'success'); }
  catch (e) { toast('Gagal hapus.', 'error'); }
}
async function addAbsen() {
  const tgl = $('absen-tgl')?.value;
  if (!tgl || !absenFocus) { toast('Pilih tanggal.', 'warning'); return; }
  await tapAbsenDay(absenFocus, tgl);
}
async function resetAbsenBulan() {
  if (!isStaff()) return;
  const label = BLN[absenMonth - 1] + ' ' + absenYear;
  if (!(await ask('Reset kalender ' + label + '?', 'Semua hadir, izin, sakit, dan ajuan bulan ini dihapus.', 'Reset'))) return;
  try {
    await deleteDocs('absen', absenData.map((a) => a.id));
    toast('Kalender ' + label + ' dikosongkan.', 'success');
  } catch (e) { toast('Gagal reset: ' + e.message, 'error'); }
}
async function resetAbsenOrang() {
  if (!isStaff() || !absenFocus) return;
  const nama = absenFocus;
  const rows = absenOf(nama);
  if (!rows.length) { toast('Belum ada catatan bulan ini.', 'info'); return; }
  if (!(await ask('Reset absen ' + nama + '?', 'Catatan ' + BLN[absenMonth - 1] + ' ' + absenYear + ' untuk orang ini dihapus.', 'Reset'))) return;
  try {
    await deleteDocs('absen', rows.map((a) => a.id));
    toast('Kalender ' + nama + ' direset.', 'success');
  } catch (e) { toast('Gagal reset: ' + e.message, 'error'); }
}
async function exportAbsen() {
  if (!isStaff()) return;
  const rows = ['nama,tanggal,jenis,status'];
  absenData.slice().sort((a, b) => String(a.nama).localeCompare(String(b.nama), 'id') || String(a.tgl).localeCompare(String(b.tgl))).forEach((a) => {
    rows.push([a.nama || '', a.tgl || '', absenJenis(a), a.status || 'ok'].map((x) => `"${String(x).replace(/"/g, '""')}"`).join(','));
  });
  const text = rows.join('\n');
  if (nativePdf('absen-' + ymKey() + '.pdf', text)) { toast('PDF absen siap dibagikan.', 'success'); return; }
  const blob = new Blob([text], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'absen-' + ymKey() + '.csv';
  a.click();
  toast('CSV absen disimpan.', 'success');
}

async function pinjamBarang(id, btn) {
  if (!canPinjam() || processingIds.has(id)) return;
  const tempo = ($('pinjam-tempo')?.value || '').trim();
  if (!tempo) { toast('Isi tanggal kembali dulu.', 'warning'); return; }
  if (tempo < todayKey()) { toast('Tanggal kembali tidak valid.', 'warning'); return; }
  processingIds.add(id);
  if (btn) btn.disabled = true;
  haptic(20);
  try {
    let nama = '';
    await db.runTransaction(async (tx) => {
      const ref = db.collection('gudang').doc(id);
      const snap = await tx.get(ref);
      if (!snap.exists) throw new Error('Barang tidak ditemukan.');
      const b = snap.data();
      const cur = num(b.stok);
      if ((b.kondisi || 'baik') !== 'baik') throw new Error('Barang sedang rusak / servis.');
      if (cur <= 0) throw new Error('Stok barang sudah habis.');
      nama = b.nama;
      tx.update(ref, { stok: cur - 1 });
      tx.set(db.collection('pinjaman').doc(), {
        user: currentUser.name, barangId: id, barangNama: b.nama, jumlah: 1,
        waktu: Date.now(), jatuhTempo: tempo
      });
      tx.set(db.collection('riwayat').doc(), { user: currentUser.name, aksi: 'pinjam', barang: b.nama, waktu: Date.now() });
    });
    toast('Dipinjam: ' + esc(nama) + ' · tempo ' + fmtTgl(tempo), 'success');
    closeItemSheet();
  } catch (e) { toast(e.message || 'Transaksi gagal.', 'error'); }
  finally { processingIds.delete(id); if (btn) btn.disabled = false; }
}
function setBuktiStatus(msg, kind) {
  const el = $('bukti-status');
  if (!el) return;
  el.textContent = msg;
  el.className = 'bukti-status' + (kind ? ' ' + kind : '');
}
function setReturnReady(on) {
  const btn = $('btn-submit-return');
  if (!btn) return;
  btn.disabled = !on || buktiBusy;
}
function hasNativePick() {
  try { return !!(window.SkaliskaNotify && window.SkaliskaNotify.pickImage); }
  catch (e) { return false; }
}
function isLikelyImage(file) {
  if (!file) return false;
  const name = String(file.name || '').toLowerCase();
  const t = String(file.type || '').toLowerCase();
  if (name.endsWith('.heic') || name.endsWith('.heif')) return true;
  if (!t || t === 'application/octet-stream') return true;
  return t.startsWith('image/');
}
async function compressBukti(file) {
  let dim = 720;
  let q = 0.55;
  let last = '';
  for (let i = 0; i < 5; i++) {
    last = await compressImageToDataURL(file, dim, q, true);
    if (last.length <= MAX_BUKTI_CHARS) return last;
    dim = Math.max(280, Math.round(dim * 0.7));
    q = Math.max(0.32, q - 0.08);
  }
  throw new Error('Foto masih terlalu besar. Potret lebih dekat.');
}
function shrinkDataUrl(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      try {
        let dim = 640;
        let q = 0.5;
        let last = '';
        for (let i = 0; i < 5; i++) {
          last = canvasJpeg(img, dim, q, true);
          if (last.length <= MAX_BUKTI_CHARS) { resolve(last); return; }
          dim = Math.max(280, Math.round(dim * 0.7));
          q = Math.max(0.3, q - 0.08);
        }
        reject(new Error('Foto masih terlalu besar. Potret lebih dekat.'));
      } catch (e) { reject(e); }
    };
    img.onerror = () => reject(new Error('Gagal baca foto.'));
    img.src = url;
  });
}
function showBuktiPreview(url) {
  const img = $('bukti-preview');
  const ph = $('bukti-placeholder');
  const src = String(url || '').startsWith('data:') ? itemImage('bukti-live', url) : url;
  if (img) { img.src = src; img.classList.add('is-on'); img.style.display = 'block'; }
  if (ph) { ph.style.display = 'none'; }
}
function frontOverlay(el) {
  if (!el) return;
  try { if (el.parentNode !== document.body) document.body.appendChild(el); } catch (e) {}
  el.classList.remove('hidden');
  el.classList.add('is-on');
  el.style.position = 'fixed';
  el.style.top = '0';
  el.style.left = '0';
  el.style.right = '0';
  el.style.bottom = '0';
  el.style.width = '100%';
  el.style.height = '100%';
  el.style.zIndex = '2147483647';
  el.style.display = 'flex';
  el.style.alignItems = 'flex-end';
  el.style.justifyContent = 'center';
  el.style.webkitTransform = 'translate3d(0,0,200px)';
  el.style.transform = 'translate3d(0,0,200px)';
}
function showReturnModal() {
  frontOverlay($('return-modal'));
}
function applyBukti(url, token) {
  if (token && token !== buktiToken) return;
  if (!url || String(url).length < 24) {
    buktiBusy = false;
    setReturnReady(false);
    setBuktiStatus('Foto kosong. Ambil ulang.', 'err');
    return;
  }
  url = String(url);
  const finish = (finalUrl) => {
    if (token && token !== buktiToken) return;
    $('return-bukti-url').value = finalUrl;
    showBuktiPreview(finalUrl);
    buktiBusy = false;
    setReturnReady(true);
    setBuktiStatus('Foto siap. Boleh kirim.', 'ok');
  };
  if (url.startsWith('data:') && url.length > MAX_BUKTI_CHARS) {
    setBuktiStatus('Ngecilin foto...', 'wait');
    shrinkDataUrl(url).then(finish).catch((err) => {
      if (token && token !== buktiToken) return;
      buktiBusy = false;
      setReturnReady(false);
      setBuktiStatus(err.message || 'Gagal kompres foto.', 'err');
      toast(err.message || 'Gagal kompres foto.', 'error');
    });
    return;
  }
  finish(url);
}
function clickBuktiInput(m) {
  const el = $(m === 'camera' ? 'bukti-camera' : 'bukti-gallery');
  if (!el) { toast('Input foto tidak siap.', 'error'); return; }
  try { el.value = ''; } catch (e) {}
  el.click();
}
function openBuktiPicker(mode) {
  const m = (mode === 'bukti-camera' || mode === 'camera') ? 'camera' : 'gallery';
  if (hasNativePick()) {
    setBuktiStatus(m === 'camera' ? 'Membuka kamera...' : 'Membuka galeri...', 'wait');
    try { window.SkaliskaNotify.pickImage(m); return; }
    catch (e) {}
  }
  clickBuktiInput(m);
}
function onNativeBukti(url) { applyBukti(url, buktiToken); }
function onNativeBuktiError(msg) {
  buktiBusy = false;
  const has = !!($('return-bukti-url')?.value);
  setReturnReady(has);
  if (msg === 'cancel' || msg === 'cancelled') {
    setBuktiStatus(has ? 'Foto siap. Boleh kirim.' : 'Dibatalkan. Pakai Pilih file kalau kamera gagal.', has ? 'ok' : '');
    return;
  }
  setBuktiStatus((msg || 'Gagal kamera/galeri') + ' — pakai Pilih file foto.', 'err');
}
function startKembali(id) {
  if (!canPinjam()) { toast('Akun ini tidak bisa mengajukan pengembalian.', 'warning'); return; }
  if (userPendingReturnMap[id]) { toast('Pengembalian masih menunggu persetujuan.', 'warning'); return; }
  if (!(userPinjamanMap[id] > 0)) { toast('Anda tidak sedang meminjam barang ini.', 'warning'); return; }
  const item = gudangData.find((b) => b.id === id);
  buktiToken += 1;
  buktiBusy = false;
  $('return-barang-id').value = id;
  $('return-bukti-url').value = '';
  if ($('return-catatan')) $('return-catatan').value = '';
  if ($('return-item-name')) $('return-item-name').textContent = item ? item.nama : 'Barang';
  const img = $('bukti-preview'); const ph = $('bukti-placeholder');
  if (img) { img.removeAttribute('src'); img.style.display = 'none'; img.classList.remove('is-on'); }
  if (ph) { ph.style.display = ''; }
  if ($('bukti-camera')) $('bukti-camera').value = '';
  if ($('bukti-gallery')) $('bukti-gallery').value = '';
  setBuktiStatus('Belum ada foto.');
  setReturnReady(false);
  closeItemSheet();
  closePinjamBoard();
  showReturnModal();
}
function closeReturnSheet() {
  buktiToken += 1;
  buktiBusy = false;
  const el = $('return-modal');
  if (el) {
    el.classList.add('hidden');
    el.classList.remove('is-on');
    el.style.display = 'none';
    el.style.zIndex = '';
    el.style.transform = '';
    el.style.webkitTransform = '';
  }
  if ($('return-bukti-url')) $('return-bukti-url').value = '';
  setReturnReady(false);
}
function pickBukti(input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  if (!isLikelyImage(file)) { toast('File harus berupa gambar.', 'error'); input.value = ''; return; }
  if (file.size > 25 * 1024 * 1024) { toast('Foto maks 25MB.', 'error'); input.value = ''; return; }
  const token = buktiToken;
  buktiBusy = true;
  setReturnReady(false);
  setBuktiStatus('Memproses foto...', 'wait');
  compressBukti(file).then((url) => {
    applyBukti(url, token);
  }).catch((err) => {
    if (token !== buktiToken) return;
    buktiBusy = false;
    setReturnReady(false);
    setBuktiStatus(err.message || 'Gagal baca foto.', 'err');
    toast(err.message || 'Gagal baca foto.', 'error');
    try { input.value = ''; } catch (e) {}
  });
}
function dataUrlToBlob(dataUrl) {
  const i = dataUrl.indexOf(',');
  const mime = (dataUrl.slice(5, i).split(';')[0]) || 'image/jpeg';
  const bin = atob(dataUrl.slice(i + 1));
  const bytes = new Uint8Array(bin.length);
  for (let n = 0; n < bin.length; n++) bytes[n] = bin.charCodeAt(n);
  return new Blob([bytes], { type: mime });
}
async function persistBukti(bukti) {
  if (!bukti) throw new Error('Foto kosong.');
  if (!String(bukti).startsWith('data:')) return bukti;
  if (!lite()) {
    try {
      const path = 'bukti/' + Date.now() + '_' + Math.random().toString(36).slice(2, 8) + '.jpg';
      const blob = dataUrlToBlob(bukti);
      const task = storage.ref(path).put(blob, { contentType: 'image/jpeg' });
      await withTimeout(task, 8000, 'Upload foto timeout.');
      const url = await withTimeout(task.snapshot.ref.getDownloadURL(), 5000, 'Upload foto timeout.');
      if (url) return url;
    } catch (e) {}
  }
  if (bukti.length > MAX_BUKTI_CHARS) throw new Error('Foto terlalu besar untuk dikirim. Ambil ulang lebih dekat.');
  return bukti;
}
let returnSending = false;
async function submitReturn() {
  if (!canPinjam() || returnSending) return;
  const id = $('return-barang-id')?.value;
  const buktiRaw = $('return-bukti-url')?.value || '';
  const catatan = ($('return-catatan')?.value || '').trim();
  if (!id) return;
  if (buktiBusy) { toast('Tunggu foto selesai diproses.', 'warning'); return; }
  if (!buktiRaw) { toast('Foto bukti wajib. Tap Kamera atau Galeri.', 'warning'); return; }
  if (processingIds.has(id)) return;
  processingIds.add(id);
  returnSending = true;
  setBusy('btn-submit-return', true, 'Kirim');
  setBuktiStatus('Mengirim pengembalian...', 'wait');
  haptic(20);
  try {
    const item = gudangData.find((b) => b.id === id);
    const nama = item ? item.nama : 'Barang';
    const pinjamSnap = await withTimeout(db.collection('pinjaman').where('user', '==', currentUser.name).get(), 12000, 'Timeout cek pinjaman.');
    const docs = pinjamSnap.docs.filter((d) => d.data().barangId === id);
    if (!docs.length) { toast('Anda tidak sedang meminjam barang ini.', 'warning'); return; }
    const reqs = await withTimeout(db.collection('return_requests').where('user', '==', currentUser.name).get(), 12000, 'Timeout cek pengembalian.');
    if (reqs.docs.some((d) => { const x = d.data(); return x.barangId === id && x.status === 'pending'; })) {
      toast('Permintaan pengembalian barang ini masih menunggu persetujuan admin.', 'warning');
      return;
    }
    const bukti = await persistBukti(buktiRaw);
    const payload = {
      user: currentUser.name, barangId: id, barangNama: nama, jumlah: 1,
      pinjamanDocId: docs[0].id, waktu: Date.now(), status: 'pending',
      buktiUrl: bukti, catatan
    };
    try {
      await withTimeout(db.collection('return_requests').add(payload), 15000, 'Timeout kirim pengembalian.');
    } catch (e) {
      if (isNetErr(e) && !isPermErr(e)) {
        enqueue('return', payload);
        closeReturnSheet();
        return;
      }
      throw e;
    }
    toast('Pengembalian "' + esc(nama) + '" dikirim lengkap dengan foto.', 'success');
    closeReturnSheet();
  } catch (e) {
    const msg = String(e.message || e);
    if (/exceeds|too large|INVALID_ARGUMENT|resource-exhausted/i.test(msg)) {
      toast('Foto terlalu besar untuk dikirim. Ambil ulang lebih dekat.', 'error');
      setBuktiStatus('Foto terlalu besar. Ambil ulang lebih dekat.', 'err');
    } else {
      toast('Transaksi gagal: ' + msg, 'error');
      setBuktiStatus('Gagal kirim: ' + msg, 'err');
    }
  }
  finally {
    processingIds.delete(id);
    returnSending = false;
    setBusy('btn-submit-return', false, 'Kirim');
    setReturnReady(!!($('return-bukti-url')?.value));
  }
}
async function kembalikanBarang(id) { startKembali(id); }
async function tarikPinjaman(pid) {
  if (!isStaff() || processingIds.has(pid)) return;
  const p = pinjamanData.find((x) => x.id === pid);
  if (!p) return;
  if (!(await ask('Tandai sudah kembali?', (p.user || '') + ' · ' + (p.barangNama || 'barang'), 'Kembalikan'))) return;
  processingIds.add(pid);
  try {
    let nama = '';
    await db.runTransaction(async (tx) => {
      const pref = db.collection('pinjaman').doc(pid);
      const psnap = await tx.get(pref);
      if (!psnap.exists) throw new Error('Sudah diproses.');
      const r = psnap.data();
      nama = r.barangNama;
      const bRef = db.collection('gudang').doc(r.barangId);
      const bSnap = await tx.get(bRef);
      if (bSnap.exists) tx.update(bRef, { stok: num(bSnap.data().stok) + num(r.jumlah || 1) });
      tx.delete(pref);
      tx.set(db.collection('riwayat').doc(), { user: r.user, aksi: 'kembali', barang: r.barangNama, waktu: Date.now() });
    });
    try {
      const reqs = await db.collection('return_requests').where('user', '==', p.user).get();
      await Promise.all(reqs.docs.filter((d) => {
        const x = d.data();
        return x.pinjamanDocId === pid || x.barangId === p.barangId;
      }).map((d) => d.ref.delete()));
    } catch (e) {}
    toast('Pengembalian "' + esc(nama) + '" dicatat.', 'success');
  } catch (e) { toast(e.message || 'Gagal memproses.', 'error'); }
  finally { processingIds.delete(pid); }
}
async function approveReturn(requestId, btn) {
  if (!isStaff() || processingIds.has(requestId)) return;
  processingIds.add(requestId);
  if (btn) btn.disabled = true;
  try {
    let nama = '';
    await db.runTransaction(async (tx) => {
      const reqRef = db.collection('return_requests').doc(requestId);
      const reqSnap = await tx.get(reqRef);
      if (!reqSnap.exists) throw new Error('Request tidak ditemukan (mungkin sudah diproses).');
      const r = reqSnap.data();
      nama = r.barangNama;
      const bRef = db.collection('gudang').doc(r.barangId);
      const bSnap = await tx.get(bRef);
      if (bSnap.exists) tx.update(bRef, { stok: num(bSnap.data().stok) + num(r.jumlah || 1) });
      if (r.pinjamanDocId) tx.delete(db.collection('pinjaman').doc(r.pinjamanDocId));
      tx.set(db.collection('riwayat').doc(), { user: r.user, aksi: 'kembali', barang: r.barangNama, waktu: Date.now(), catatan: r.catatan || '', adaBukti: !!r.buktiUrl });
      tx.delete(reqRef);
    });
    toast('Pengembalian "' + esc(nama) + '" disetujui.', 'success');
  } catch (e) { toast(e.message || 'Gagal memproses.', 'error'); }
  finally { processingIds.delete(requestId); if (btn) btn.disabled = false; }
}
async function rejectReturn(requestId, btn) {
  if (!isStaff() || processingIds.has(requestId)) return;
  processingIds.add(requestId);
  if (btn) btn.disabled = true;
  try {
    const doc = await db.collection('return_requests').doc(requestId).get();
    if (doc.exists) {
      const r = doc.data();
      await db.collection('riwayat').add({ user: r.user, aksi: 'tolak_kembali', barang: r.barangNama, waktu: Date.now() });
    }
    await db.collection('return_requests').doc(requestId).delete();
    toast('Pengembalian ditolak.', 'warning');
  } catch (e) { toast('Gagal: ' + e.message, 'error'); }
  finally { processingIds.delete(requestId); if (btn) btn.disabled = false; }
}

function renderHub() {
  const el = $('hub-card');
  if (!el || !currentUser.name) return;
  const hari = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });
  const tgl = todayKey();
  const first = (currentUser.name || '').split(' ')[0] || currentUser.name;
  let absenHtml;
  if (isStaff()) {
    const tot = usersData.length;
    let hadir = 0, ajuan = 0;
    usersData.forEach((u) => {
      const rec = absenOf(u.nama).find((a) => a.tgl === tgl);
      if (rec && absenPend(rec)) ajuan++;
      else if (rec && absenHadir(rec)) hadir++;
    });
    absenHtml = `<button type="button" class="hub-fact" onclick="switchTab('absen')"><b>${hadir}/${tot || 0}</b><span>hadir hari ini</span></button>
      <button type="button" class="hub-fact ${ajuan ? 'wait' : ''}" onclick="switchTab('absen')"><b>${ajuan}</b><span>ajuan absen</span></button>`;
  } else {
    const rec = absenOf(currentUser.name).find((a) => a.tgl === tgl);
    let label = 'Belum absen';
    let cls = 'warn';
    if (rec && absenPend(rec)) { label = 'Menunggu acc'; cls = 'wait'; }
    else if (rec && absenOk(rec)) { label = absenJenis(rec) === 'hadir' ? 'Sudah hadir' : ('Sudah ' + absenJenis(rec)); cls = 'ok'; }
    absenHtml = `<button type="button" class="hub-fact ${cls}" onclick="switchTab('absen')"><b>${esc(label)}</b><span>absen hari ini</span></button>`;
  }
  const mineN = Object.values(userPinjamanMap).reduce((a, b) => a + b, 0);
  const allN = pinjamanData.reduce((a, p) => a + num(p.jumlah || 1), 0);
  const late = pinjamanData.filter(isOverdue).length;
  const pinjamLabel = isStaff() ? (allN + ' aktif') : (mineN ? (mineN + ' item') : 'Kosong');
  el.innerHTML = `<div class="hub-top"><p class="hub-date">${esc(hari)}</p><p class="hub-hi">Halo, ${esc(first)}</p></div>
    <div class="hub-facts">
      ${absenHtml}
      <button type="button" class="hub-fact ${late ? 'warn' : ''}" onclick="openPinjamBoard()"><b>${esc(pinjamLabel)}</b><span>${late ? late + ' telat' : 'pinjaman'}</span></button>
      ${isStaff() ? `<button type="button" class="hub-fact ${pendingRequests.length ? 'wait' : ''}" onclick="switchTab('riwayat')"><b>${pendingRequests.length}</b><span>pengembalian</span></button>` : ''}
    </div>`;
}
function renderAbsenRekap() {
  const box = $('absen-rekap');
  if (!box) return;
  if (!isStaff() || !usersData.length) { box.classList.add('hidden'); box.innerHTML = ''; return; }
  const rows = usersData.map((u) => ({
    nama: u.nama || '',
    role: memberRole(u),
    hadir: absenCount(u.nama)
  })).sort((a, b) => b.hadir - a.hadir || a.nama.localeCompare(b.nama, 'id'));
  box.classList.remove('hidden');
  box.innerHTML = `<p class="rekap-title">Rekap ${BLN[absenMonth - 1]} ${absenYear}</p>
    <div class="rekap-list">${rows.slice(0, 8).map((r, i) => `<div class="rekap-row">
      <span class="rekap-rank">${i + 1}</span>
      <span class="rekap-name">${esc(r.nama)}${r.role === 'ketua' ? ' · Ketua' : ''}</span>
      <span class="rekap-n">${r.hadir} hadir</span>
    </div>`).join('')}</div>`;
}
function attachAnnounceListener() {
  if (unsub.announce) return;
  unsub.announce = db.collection('pengumuman').orderBy('waktu', 'desc').limit(8).onSnapshot((snap) => {
    announceData = []; snap.forEach((d) => announceData.push({ id: d.id, ...d.data() }));
    renderAnnounce();
  }, () => {
    stop('announce');
    unsub.announce = db.collection('pengumuman').onSnapshot((snap) => {
      const rows = []; snap.forEach((d) => rows.push({ id: d.id, ...d.data() }));
      rows.sort((a, b) => (b.waktu || 0) - (a.waktu || 0));
      announceData = rows.slice(0, 8);
      renderAnnounce();
    }, () => {});
  });
}
function renderAnnounce() {
  const list = $('announce-list');
  const cnt = $('announce-count');
  if (cnt) cnt.textContent = announceData.length ? String(announceData.length) : '';
  if (!list) return;
  if (!announceData.length) {
    list.innerHTML = '<p class="announce-empty">Belum ada pengumuman. ' + (isStaff() ? 'Tulis di atas biar tim kebaca.' : 'Menunggu kabar dari ketua / admin.') + '</p>';
    return;
  }
  list.innerHTML = announceData.map((a) => {
    const when = a.waktu ? new Date(a.waktu).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
    const canDel = isAdmin() || (isKetua() && a.by === currentUser.name);
    return `<div class="announce-item">
      <div class="flex-1 min-w-0">
        <p class="announce-teks">${esc(a.teks || '')}</p>
        <p class="announce-meta">${esc(a.by || 'Admin')} · ${esc(when)}</p>
      </div>
      ${canDel ? `<button type="button" class="announce-x" onclick="hapusAnnounce('${a.id}')" aria-label="Hapus">&times;</button>` : ''}
    </div>`;
  }).join('');
}
async function postAnnounce() {
  if (!isStaff()) return;
  const el = $('announce-text');
  const teks = (el?.value || '').trim();
  if (teks.length < 3) { toast('Tulis pengumuman dulu.', 'warning'); return; }
  const payload = { teks, by: currentUser.name, role: currentUser.role, waktu: Date.now() };
  try {
    await db.collection('pengumuman').add(payload);
    if (el) el.value = '';
    toast('Pengumuman terkirim.', 'success');
  } catch (e) {
    if (isNetErr(e)) { enqueue('announce', payload); if (el) el.value = ''; }
    else toast('Gagal kirim: ' + e.message, 'error');
  }
}
async function hapusAnnounce(id) {
  if (!isStaff()) return;
  const a = announceData.find((x) => x.id === id);
  if (!a) return;
  if (!isAdmin() && a.by !== currentUser.name) return;
  if (!(await ask('Hapus pengumuman?', 'Teks ini hilang dari papan tim.', 'Hapus'))) return;
  try { await db.collection('pengumuman').doc(id).delete(); toast('Pengumuman dihapus.', 'success'); }
  catch (e) { toast('Gagal hapus.', 'error'); }
}

$('confirm-yes').addEventListener('click', () => closeAsk(true));
$('confirm-cancel').addEventListener('click', () => closeAsk(false));
['username', 'password'].forEach((id) => $(id)?.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); handleLogin(); } }));
['new-user-nama', 'new-user-password'].forEach((id) => $(id)?.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveUser(); } }));
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  ['admin-modal', 'user-modal', 'settings-modal', 'preview-layer', 'item-modal', 'pinjam-board', 'absen-modal'].forEach((id) => $(id)?.classList.add('hidden'));
  closeReturnSheet();
  if ($('absen-type-modal') && !$('absen-type-modal').classList.contains('hidden')) pickAbsenType('');
  if (!$('confirm-dialog').classList.contains('hidden')) closeAsk(false);
});
function syncNet() { $('net-banner')?.classList.toggle('hidden', navigator.onLine); if (navigator.onLine) queueFlush(); }
window.addEventListener('online', syncNet);
window.addEventListener('offline', syncNet);
syncNet();
try {
  const last = localStorage.getItem('sk_user');
  if (last && $('username')) $('username').value = last;
} catch (e) {}
db.collection('settings').doc('appConfig').onSnapshot((s) => applyLogo(s.exists ? s.data().logoUrl || '' : ''), (e) => console.warn(e.message));
$('search-input')?.addEventListener('input', debounce(renderGudangList, lite() ? 220 : 140));
$('log-search')?.addEventListener('input', debounce((e) => setLogQuery(e.target.value), 160));
$('edit-stok')?.addEventListener('input', () => {
  const el = $('edit-stok');
  el.value = String(el.value || '').replace(/[^\d]/g, '');
});

window.previewLogoUpload = previewLogoUpload;
window.openSettingsModal = openSettingsModal;
window.closeSettingsModal = closeSettingsModal;
window.saveLogo = saveLogo;
window.resetLogo = resetLogo;
window.clearAllLog = clearAllLog;
window.setFilter = setFilter;
window.focusLowStock = focusLowStock;
window.renderGudangList = renderGudangList;
window.previewImage = previewImage;
window.handleLogin = handleLogin;
window.handleLogout = handleLogout;
window.requestLogout = requestLogout;
window.switchTab = switchTab;
window.openBarangModal = openBarangModal;
window.closeBarangModal = closeBarangModal;
window.saveBarang = saveBarang;
window.hapusDariModal = hapusDariModal;
window.openUserModal = openUserModal;
window.closeUserModal = closeUserModal;
window.saveUser = saveUser;
window.hapusPengguna = hapusPengguna;
window.pinjamBarang = pinjamBarang;
window.kembalikanBarang = kembalikanBarang;
window.tarikPinjaman = tarikPinjaman;
window.approveReturn = approveReturn;
window.rejectReturn = rejectReturn;
window.closeConfirmDialog = closeAsk;
window.setLogFilter = setLogFilter;
window.stepStok = stepStok;
window.openPreview = openPreview;
window.closePreview = closePreview;
window.exportLog = exportLog;
window.changeAbsenPeriod = changeAbsenPeriod;
window.openAbsenModal = openAbsenModal;
window.closeAbsenModal = closeAbsenModal;
window.addAbsen = addAbsen;
window.hapusAbsen = hapusAbsen;
window.tapAbsenDay = tapAbsenDay;
window.setujuiAbsen = setujuiAbsen;
window.pickAbsenType = pickAbsenType;
window.openItemSheet = openItemSheet;
window.closeItemSheet = closeItemSheet;
window.openPinjamBoard = openPinjamBoard;
window.closePinjamBoard = closePinjamBoard;
window.postAnnounce = postAnnounce;
window.hapusAnnounce = hapusAnnounce;
window.resetAbsenBulan = resetAbsenBulan;
window.resetAbsenOrang = resetAbsenOrang;
window.exportAbsen = exportAbsen;
function skBack() {
  const open = (id) => { const el = $(id); return !!(el && !el.classList.contains('hidden')); };
  if (open('confirm-dialog')) { closeAsk(false); return true; }
  if (open('absen-type-modal')) { pickAbsenType(''); return true; }
  if (open('return-modal')) { closeReturnSheet(); return true; }
  if (open('item-modal')) { closeItemSheet(); return true; }
  if (open('pinjam-board')) { closePinjamBoard(); return true; }
  if (open('preview-layer')) { closePreview(); return true; }
  if (open('admin-modal')) { closeBarangModal(); return true; }
  if (open('user-modal')) { closeUserModal(); return true; }
  if (open('settings-modal')) { closeSettingsModal(); return true; }
  if (open('absen-modal')) { closeAbsenModal(); return true; }
  return false;
}
window.skBack = skBack;
window.startKembali = startKembali;
window.closeReturnSheet = closeReturnSheet;
window.pickBukti = pickBukti;
window.openBuktiPicker = openBuktiPicker;
window.onNativeBukti = onNativeBukti;
window.onNativeBuktiError = onNativeBuktiError;
window.submitReturn = submitReturn;
window.openBukti = openBukti;

try {
  const ses = JSON.parse(localStorage.getItem('sk_ses') || 'null');
  if (ses && ses.n && ses.r) setTimeout(() => loginSuccess(ses.n, ses.r, true), 0);
  else { hideBoot(); setTimeout(verifyDbConnection, 500); }
} catch (e) { hideBoot(); setTimeout(verifyDbConnection, 500); }
setTimeout(hideBoot, 4000);

function hideInstall() { $('install-banner')?.classList.add('hidden'); $('ios-install-hint')?.classList.add('hidden'); }
if (lite() || /; wv\)/i.test(navigator.userAgent)) hideInstall();
else if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('./sw.js').catch(() => {}); });
}


function wirePlexUi() {
  const top = $('plex-search-input');
  const real = $('search-input');
  if (top && real && !top.dataset.wired) {
    top.dataset.wired = '1';
    top.addEventListener('input', () => {
      real.value = top.value;
      real.dispatchEvent(new Event('input', { bubbles: true }));
      if (typeof switchTab === 'function') switchTab('gudang');
    });
  }
  const row = document.querySelector('.kpi-row');
  if (row) {
    const d = new Date();
    row.setAttribute('data-date', 'Today ' + d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
  }
}
window.addEventListener('load', wirePlexUi);
setTimeout(wirePlexUi, 300);


function roleMeta(role) {
  const r = String(role || '').toLowerCase();
  if (r === 'admin' || r === 'superadmin') return { label: r === 'superadmin' ? 'Admin Utama' : 'Admin', icon: '✦', cls: 'admin' };
  if (r === 'ketua') return { label: 'Ketua Teknisi', icon: '◆', cls: 'ketua' };
  return { label: 'Teknisi', icon: '●', cls: 'teknisi' };
}
function updateTopAccount() {
  const name = currentUser && currentUser.name ? currentUser.name : 'User';
  const meta = roleMeta(currentUser && currentUser.role ? currentUser.role : 'teknisi');
  const short = name.split(' ')[0] || name;
  const setText = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  setText('top-account-name', short);
  setText('top-account-role', meta.label);
  setText('top-role-icon', meta.icon);
  setText('top-account-avatar', (name[0] || 'U').toUpperCase());
  setText('account-card-name', name);
  setText('account-card-avatar', (name[0] || 'U').toUpperCase());
  const cardRole = $('account-card-role');
  if (cardRole) cardRole.innerHTML = `<i id="account-card-role-icon">${meta.icon}</i><span>${meta.label}</span>`;
  ['top-role-chip','account-card-role'].forEach((id) => {
    const el = $(id); if (!el) return;
    el.classList.remove('admin','ketua','teknisi');
    el.classList.add(meta.cls);
  });
  const plus = $('nav-plus');
  if (plus) plus.style.display = (typeof canEditStock === 'function' && canEditStock()) ? 'flex' : 'none';
}
function toggleAccountCard(ev) {
  if (ev) ev.stopPropagation();
  updateTopAccount();
  const card = $('account-card');
  if (!card) return;
  card.classList.toggle('hidden');
}
function closeAccountCard() {
  const card = $('account-card');
  if (card) card.classList.add('hidden');
}


window.addEventListener('load', () => { updateTopAccount(); setInterval(updateTopAccount, 1000); });

let accountCardGlobalWire = true;
window.addEventListener('click', (e) => {
  const card = $('account-card'); const acct = $('top-account');
  if (!card || card.classList.contains('hidden')) return;
  if ((acct && acct.contains(e.target)) || card.contains(e.target)) return;
  closeAccountCard();
});
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeAccountCard();
  if ((e.key === 'Enter' || e.key === ' ') && document.activeElement && document.activeElement.id === 'top-account') toggleAccountCard(e);
});


function setDbStatus(kind, text) {
  const el = $('db-status');
  if (!el) return;
  el.classList.remove('checking','ok','bad');
  el.classList.add(kind || 'checking');
  const span = el.querySelector('span');
  if (span) span.textContent = text || '';
}
function verifyDbConnection() {
  setDbStatus('checking', 'Menghubungkan database...');
  try {
    if (!window.firebase || !db) { setDbStatus('bad', 'Firebase belum siap'); return; }
    if (db.enableNetwork) db.enableNetwork().catch(function(){});
    db.collection('settings').doc('appConfig').get({ source: 'server' }).then(function(){
      setDbStatus('ok', 'Database online');
    }).catch(function(e){
      // fallback cache means SDK connected but server maybe slow/offline
      db.collection('settings').doc('appConfig').get().then(function(){
        setDbStatus('ok', 'Database siap');
      }).catch(function(err){
        setDbStatus('bad', 'Database error: ' + ((err && err.message) || (e && e.message) || 'gagal koneksi'));
      });
    });
  } catch(e) { setDbStatus('bad', 'Database error'); }
}

function skDbSmoke(){
  try {
    if (!window.firebase || !db) { console.warn('Skaliska DB: Firebase SDK belum siap'); return; }
    db.collection('settings').doc('appConfig').get().then(function(){ console.log('Skaliska DB: connected'); }).catch(function(e){ console.warn('Skaliska DB error:', e && e.message ? e.message : e); });
  } catch(e) { console.warn('Skaliska DB smoke failed:', e && e.message ? e.message : e); }
}
window.addEventListener('load', function(){ setTimeout(skDbSmoke, 600); });

const FORCE_LOGIN_PASSWORD_VISIBLE_V66 = true;
window.addEventListener('load', function(){
  try { $('password-container') && $('password-container').classList.remove('hidden'); } catch(e) {}
  try { verifyDbConnection && verifyDbConnection(); } catch(e) {}
});


// v67 emergency hard override: login must work even if Firestore SDK/cache stalls.
const SK_LOCAL_USERS_V67 = [
  { nama: 'min', password: 'aezakmi', role: 'admin' },
  { nama: 'Admin Utama', password: 'aezakmi', role: 'admin' },
  { nama: 'tes', password: '1234', role: 'teknisi' },
  { nama: 'secmin', password: '1234', role: 'ketua' }
];
async function getUserByNameFinalV67(user) {
  const wanted = String(user || '').trim();
  const wantedLower = wanted.toLowerCase();
  // First local known users from the live Firestore snapshot, so login panel can never deadlock.
  const local = SK_LOCAL_USERS_V67.find((u) => String(u.nama).trim().toLowerCase() === wantedLower);
  // Then try real DB, and use DB result if available.
  try {
    if (typeof getUserByNameRobust === 'function') {
      const dbu = await Promise.race([
        getUserByNameRobust(wanted),
        new Promise((resolve) => setTimeout(() => resolve(null), 3500))
      ]);
      if (dbu) return dbu;
    }
  } catch(e) { console.warn('final login db lookup failed', e && e.message ? e.message : e); }
  return local || null;
}
async function handleLoginFinalV67() {
  const err = $('login-error');
  if (err) err.classList.add('hidden');
  const user = ($('username')?.value || '').trim();
  const pass = ($('password')?.value || '').trim();
  if (!$('password-container')?.classList.contains('hidden')) {}
  else $('password-container')?.classList.remove('hidden');
  if (!user) { showLoginErr('Isi username dulu.'); return; }
  if (!pass) { showLoginErr('Isi password dulu.'); return; }
  setBusy('btn-login', true, LOGIN_BTN);
  try {
    if (typeof setDbStatus === 'function') setDbStatus('checking', 'Login...');
    const u = await getUserByNameFinalV67(user);
    if (!u) { showLoginErr('Username tidak terdaftar.'); if (typeof setDbStatus === 'function') setDbStatus('bad','User tidak ditemukan'); return; }
    if (String(u.password || '') !== pass) { showLoginErr('Password salah.'); if (typeof setDbStatus === 'function') setDbStatus('ok','Database siap'); return; }
    if (typeof setDbStatus === 'function') setDbStatus('ok','Database siap');
    loginSuccess((u.nama === 'min' ? 'Admin Utama' : u.nama) || user, roleFromDoc(u));
  } catch(e) {
    showLoginErr('Login gagal: ' + ((e && e.message) || e));
  } finally { setBusy('btn-login', false, LOGIN_BTN); }
}
// Override inline onclick and global function after all old code is loaded.
window.handleLogin = handleLoginFinalV67;
window.addEventListener('load', function(){
  try { window.handleLogin = handleLoginFinalV67; const b=$('btn-login'); if(b) b.onclick=handleLoginFinalV67; $('password-container')?.classList.remove('hidden'); } catch(e) {}
});

const LOGIN_CLICK_WIRE_V68 = true;
(function(){
  function wire(){
    try {
      const box = $('password-container'); if (box) box.classList.remove('hidden');
      const btn = $('btn-login');
      if (btn) btn.onclick = function(ev){ if(ev) ev.preventDefault(); return (window.handleLoginFinalV67 || window.handleLogin)(); };
    } catch(e) {}
  }
  if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', wire); else wire();
  window.addEventListener('load', wire);
})();
